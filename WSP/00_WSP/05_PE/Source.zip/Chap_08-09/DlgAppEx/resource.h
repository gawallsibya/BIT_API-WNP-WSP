#define IDD_DLG_MAIN		101
#define IDR_DLG_MENU        102
#define IDI_DLG_APP         103

#define IDC_EDT_SAMPLE		1001
#define IDC_CHK_SAMPLE		1002
#define IDC_STC_ICON		1003

#define IDC_EDIT			1000
#define IDC_STATIC			1001
#define IDC_LIST_VIEW       1002
#define IDC_PROGRESSIVE		1003
#define IDC_SLIDER			1004

#define IDM_EXIT            40001

