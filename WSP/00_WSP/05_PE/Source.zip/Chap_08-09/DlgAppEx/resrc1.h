//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DlgAppEx.rc
//
#define IDI_DLG_APP                     101
#define IDC_LV_TEST                     1000
#define IDC_PROGRESS1                   1004
#define IDC_PRG_TEST                    1004
#define IDC_EDT_TEST                    1005
#define IDC_STC_TEST                    1006
#define IDC_SLIDER1                     1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
