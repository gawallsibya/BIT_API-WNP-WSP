// ResDialogDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "ResAnalyzer.h"
#include "ResDialogDlg.h"
#include ".\resdialogdlg.h"


#define DWORD_ALIGN(pAddr)	((LPWORD)(((DWORD)pAddr + 3) & ~3))

struct DLGTEMPLATEEX
{
	WORD		dlgVer;
	WORD		signature;
	DWORD		helpID;

	DWORD		exStyle;
	DWORD		style;
	WORD		cDlgItems;
	short		x;
	short		y;
	short		cx;
	short		cy;
};
typedef DLGTEMPLATEEX* LPDLGTEMPLATEEX;

struct DLGITEMTEMPLATEEX
{
	DWORD helpID;

	DWORD exStyle;
	DWORD style;
	short x;
	short y;
	short cx;
	short cy;
	WORD id;
};
typedef DLGITEMTEMPLATEEX* LPDLGITEMTEMPLATEEX;


// CResDialogDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CResDialogDlg, CDialog)
CResDialogDlg::CResDialogDlg(LPBYTE pImgStart, CWnd* pParent /*=NULL*/)
	: CDialog(CResDialogDlg::IDD, pParent)
{
	m_pImgStart	= pImgStart;
	m_bIsExt	= false;
}

CResDialogDlg::~CResDialogDlg()
{
}

void CResDialogDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CResDialogDlg, CDialog)
	ON_BN_CLICKED(IDC_BTN_SHOW_PARSE, OnBnClickedBtnShowParse)
	ON_BN_CLICKED(IDC_BTN_SHOW_DIALOG, OnBnClickedBtnShowDialog)
	ON_NOTIFY(LVN_GETDISPINFO, IDC_LV_CTRL, OnLvnGetdispinfoLvCtrl)
END_MESSAGE_MAP()


// CResDialogDlg �޽��� ó�����Դϴ�.

void CResDialogDlg::OnBnClickedBtnShowParse()
{
	LPBYTE	pImgDlg = m_pImgStart;

	CString szTemp;
	bool	bHasFont = false;
	DWORD	dwHelpID = 0;
	DWORD	dwStyle=0, dwStyleEx=0;
	INT		nCtrlCnt = 0;
	INT		x=0, y=0, w=0, h=0;
	CHAR	szWndMenu [MAX_PATH] = { 0 };
	CHAR	szWndClass[MAX_PATH] = { 0 };
	CHAR	szCaption [MAX_PATH] = { 0 };

	if(m_bIsExt)
	{
		LPDLGTEMPLATEEX pDlg = (LPDLGTEMPLATEEX)pImgDlg;
		pImgDlg += sizeof(DLGTEMPLATEEX);

		bHasFont = ((pDlg->style & DS_SETFONT) != 0);
		nCtrlCnt = pDlg->cDlgItems;
		dwHelpID = pDlg->helpID;
		dwStyle	 = pDlg->style;
		dwStyleEx= pDlg->exStyle;
		x		 = pDlg->x;
		y		 = pDlg->y;
		w		 = pDlg->cx;
		h		 = pDlg->cy;
	}
	else
	{
		LPDLGTEMPLATE pDlg = (LPDLGTEMPLATE)pImgDlg;
		pImgDlg += sizeof(DLGTEMPLATE);

		nCtrlCnt = pDlg->cdit;
		dwStyle	 = pDlg->style;
		dwStyleEx= pDlg->dwExtendedStyle;
		x		 = pDlg->x;
		y		 = pDlg->y;
		w		 = pDlg->cx;
		h		 = pDlg->cy;
	}

	LPWORD pwIter = (LPWORD)pImgDlg;

	// ��ȭ���� �޴�
	if(*pwIter == 0)
		pwIter++;
	else if(*pwIter == 0xFFFF)
	{
		pwIter++;
		*((LPWORD)szWndMenu) = *pwIter;
		pwIter++;
	}
	else
	{
		INT nUniLen = wcslen((LPWSTR)pwIter);
		INT nNameLen = CResAnalyzerApp::
			ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
								szWndMenu, sizeof(szWndMenu));
		if(!nNameLen)
		{
			CResAnalyzerApp::ShowErrorMessage(GetLastError());
			return;
		}
		pwIter += (nUniLen + 1);
	}

	// ��ȭ���� Ŭ����
	if(*pwIter)
	{
		INT nUniLen = wcslen((LPWSTR)pwIter);
		INT nNameLen = CResAnalyzerApp::
			ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
								szWndClass, sizeof(szWndClass));
		if(!nNameLen)
		{
			CResAnalyzerApp::ShowErrorMessage(GetLastError());
			return;
		}
		pwIter += (nUniLen + 1);
	}
	else
	{
		pwIter++;
	}

	// ��ȭ���� ĸ��
	if(*pwIter)
	{
		INT nUniLen = wcslen((LPWSTR)pwIter);
		INT nNameLen = CResAnalyzerApp::
			ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
								szCaption, sizeof(szCaption));
		if(!nNameLen)
		{
			CResAnalyzerApp::ShowErrorMessage(GetLastError());
			return;
		}
		pwIter += (nUniLen + 1);
	}
	else
	{
		pwIter++;
	}

	// ��Ʈ
	HFONT hFont;
	if(bHasFont)
	{
		INT nPointSize = *pwIter;
		pwIter++;
		INT nWeight = *pwIter;
		pwIter++;

		BYTE byItalic = (BYTE)((*pwIter) & 0xFF);
		BYTE byChCode = (BYTE)(((*pwIter) & 0xFF00)>>8);
		pwIter++;

		CHAR szFont[MAX_PATH];
		INT nUniLen = wcslen((LPWSTR)pwIter);
		INT nNameLen = CResAnalyzerApp::
			ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
								szFont, sizeof(szFont));
		if(!nNameLen)
		{
			CResAnalyzerApp::ShowErrorMessage(GetLastError());
			return;
		}
		pwIter += (nUniLen + 1);

		LOGFONT lf;
		memset(&lf, 0x00, sizeof(LOGFONT));
		lf.lfItalic	 = byItalic;
		lf.lfCharSet = byChCode;
		lf.lfWeight	 = nWeight;
		lf.lfHeight	 = nPointSize;
		hFont = ::CreateFontIndirect(&lf);
	}

	LONG lBaseUnit = GetDialogBaseUnits();
	LONG lXUnit = (lBaseUnit & 0x0000FFFF);
	LONG lYUnit = (lBaseUnit & 0xFFFF0000) >> 16;
	x = MulDiv(x, lXUnit, 4);
	w = MulDiv(w, lXUnit, 4);
	y = MulDiv(y, lYUnit, 8);
	h = MulDiv(h, lYUnit, 8);
	if(dwStyle & WS_CAPTION)
		h += GetSystemMetrics(SM_CYCAPTION);

	if(!szWndClass[0])
		strcpy(szWndClass, "TEST_DLG");

	WNDCLASS     wndclass;
	strcpy(szWndClass, "TEST_DLG");

	////////////////////////////////////////////////////////////////////////////
	//�������� Ŭ���� ���
	////////////////////////////////////////////////////////////////////////////
	wndclass.style         = CS_HREDRAW|CS_VREDRAW;
	wndclass.lpfnWndProc   = WndProc;
	wndclass.cbClsExtra    = 0;
	wndclass.cbWndExtra    = 0;
	wndclass.hInstance     = AfxGetInstanceHandle();
	wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName  = NULL;
	wndclass.lpszClassName = szWndClass;
	if(!RegisterClass(&wndclass))
	{
		//::MessageBox(NULL, TEXT("Window Class Registeration Failure!!!"),
		//		"TEST_MENU", MB_ICONERROR) ;
		//return;
	}

	HWND hWnd = CreateWindowEx(dwStyleEx, szWndClass, szCaption, 
							   dwStyle, x, y, w, h, GetSafeHwnd(), 
							   NULL, AfxGetInstanceHandle(), NULL);

	WORD	wItemID = 0;
	LPBYTE	pParam = NULL;
	for(INT i=0; i<nCtrlCnt; i++)
	{
		LPBYTE pCtrlIter = (LPBYTE)DWORD_ALIGN(pwIter);
		
		if(m_bIsExt)
		{
			LPDLGITEMTEMPLATEEX pItem = (LPDLGITEMTEMPLATEEX)pCtrlIter;
			pCtrlIter += sizeof(DLGITEMTEMPLATEEX);

			dwHelpID = pItem->helpID;
			dwStyle	 = pItem->style;
			dwStyleEx= pItem->exStyle;
			x		 = pItem->x;
			y		 = pItem->y;
			w		 = pItem->cx;
			h		 = pItem->cy;
			wItemID	 = pItem->id;
		}
		else
		{
			LPDLGITEMTEMPLATE pItem = (LPDLGITEMTEMPLATE)pCtrlIter;
			pCtrlIter += sizeof(DLGITEMTEMPLATE);

			dwHelpID = 0;
			dwStyle	 = pItem->style;
			dwStyleEx= pItem->dwExtendedStyle;
			x		 = pItem->x;
			y		 = pItem->y;
			w		 = pItem->cx;
			h		 = pItem->cy;
			wItemID	 = pItem->id;
		}

		if(m_bIsExt)
			pwIter = DWORD_ALIGN(pCtrlIter);
		else
			pwIter = (LPWORD)pCtrlIter;

		// ��Ʈ�� Ŭ����
		if(*pwIter == 0)
		{
			szWndClass[0] = 0x00;
			pwIter++;
		}
		else if(*pwIter == 0xFFFF)
		{
			pwIter++;
			switch(*pwIter)
			{
				case 0x0080 : strcpy(szWndClass, "BUTTON"   ); break;
				case 0x0081	: strcpy(szWndClass, "EDIT"     ); break;
				case 0x0082	: strcpy(szWndClass, "STATIC"   ); break;
				case 0x0083	: strcpy(szWndClass, "LISTBOX"  ); break;
				case 0x0084	: strcpy(szWndClass, "SCROLLBAR"); break;
				case 0x0085	: strcpy(szWndClass, "COMBOBOX" ); break;
				default		: *((LPWORD)szWndClass) = *pwIter; break; 
			}
			pwIter++;
		}
		else
		{
			INT nUniLen = wcslen((LPWSTR)pwIter);
			INT nNameLen = CResAnalyzerApp::
				ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
									szWndClass, sizeof(szWndClass));
			if(!nNameLen)
			{
				CResAnalyzerApp::ShowErrorMessage(GetLastError());
				return;
			}
			pwIter += (nUniLen + 1);
		}

		// ��Ʈ�� Ÿ��Ʋ
		if(*pwIter == 0)
		{
			szCaption[0] = 0x00;
			pwIter++;
		}
		else if(*pwIter == 0xFFFF)
		{
			pwIter++;
			*((LPWORD)szCaption) = *pwIter;
			pwIter++;
		}
		else
		{
			INT nUniLen = wcslen((LPWSTR)pwIter);
			INT nNameLen = CResAnalyzerApp::
				ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
									szCaption, sizeof(szCaption));
			if(!nNameLen)
			{
				CResAnalyzerApp::ShowErrorMessage(GetLastError());
				return;
			}
			pwIter += (nUniLen + 1);
		}

		// ���� ������
		if(*pwIter == 0)
		{
			pParam = NULL;
			pwIter++;
		}
		else
		{
			WORD wItemLen = *pwIter;
			pParam = (LPBYTE)pwIter;
			LPBYTE pTemp = pParam;
			pTemp += wItemLen;
			pwIter = (LPWORD)pTemp;
		}

		x = MulDiv(x, lXUnit, 4);
		w = MulDiv(w, lXUnit, 4);
		y = MulDiv(y, lYUnit, 8);
		h = MulDiv(h, lYUnit, 8);

		HWND hCtrl = CreateWindowEx(dwStyleEx, szWndClass, szCaption, 
									dwStyle, x, y, w, h, hWnd, (HMENU)wItemID, 
									AfxGetInstanceHandle(), pParam);
	}
	::ShowWindow(hWnd, SW_NORMAL);
	::UpdateWindow(hWnd);
}

void CResDialogDlg::OnBnClickedBtnShowDialog()
{
	LPDLGTEMPLATE pResDlg = (LPDLGTEMPLATE)m_pImgStart;
	DialogBoxIndirect(AfxGetInstanceHandle(), 
						pResDlg, GetSafeHwnd(), (DLGPROC)DlgProc);
}

LRESULT CALLBACK CResDialogDlg::WndProc(HWND hWnd, UINT uMsg, 
										WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
		case WM_CREATE:
		return TRUE;

		case WM_COMMAND:
			if(LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
			{
				::DestroyWindow(hWnd);
				return 0;
			}
		break;
	}

	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}

LRESULT CALLBACK CResDialogDlg::DlgProc(HWND hDlg, UINT uMsg, 
										WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
		case WM_INITDIALOG:
		return TRUE;

		case WM_COMMAND:
			if(LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
			{
				::EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
			}
		break;
	}

	return FALSE;
}

void CResDialogDlg::ParseDialogTemplate(CListCtrl* pLv)
{
	WORD wVer = *((LPWORD)m_pImgStart);
	WORD wSig = *((LPWORD)(m_pImgStart + sizeof(WORD)));
	if(wSig == 0xFFFF && wVer == 1)
		m_bIsExt = true;

	CString szTemp;
	DWORD	dwHelpID = 0;
	INT		nCtrlCnt = 0;
	bool	bHasFont = false;
	LPBYTE	pImgDlg = m_pImgStart;
	if(m_bIsExt)
	{
		LPDLGTEMPLATEEX pDlg = (LPDLGTEMPLATEEX)pImgDlg;
		pImgDlg += sizeof(DLGTEMPLATEEX);

		nCtrlCnt = pDlg->cDlgItems;
		dwHelpID = pDlg->helpID;
		bHasFont = ((pDlg->style & DS_SETFONT) != 0);
		szTemp.Format("(%d, %d)", pDlg->x, pDlg->y);
		SetDlgItemText(IDC_STC_XY, szTemp);
		szTemp.Format("(%d, %d)", pDlg->cx, pDlg->cy);
		SetDlgItemText(IDC_STC_WH, szTemp);
		szTemp.Format("0x%08X", pDlg->style);
		SetDlgItemText(IDC_STC_STYLE, szTemp);
		szTemp.Format("0x%08X", pDlg->exStyle);
		SetDlgItemText(IDC_STC_STYLEEX, szTemp);
	}
	else
	{
		LPDLGTEMPLATE pDlg = (LPDLGTEMPLATE)pImgDlg;
		pImgDlg += sizeof(DLGTEMPLATE);

		nCtrlCnt = pDlg->cdit;
		szTemp.Format("(%d, %d)", pDlg->x, pDlg->y);
		SetDlgItemText(IDC_STC_XY, szTemp);
		szTemp.Format("(%d, %d)", pDlg->cx, pDlg->cy);
		SetDlgItemText(IDC_STC_WH, szTemp);
		szTemp.Format("0x%08X", pDlg->style);
		SetDlgItemText(IDC_STC_STYLE, szTemp);
		szTemp.Format("0x%08X", pDlg->dwExtendedStyle);
		SetDlgItemText(IDC_STC_STYLEEX, szTemp);
	}

	LPWORD pwIter = (LPWORD)pImgDlg;
	CHAR szMenu[MAX_PATH] = { 0 };
	if(*pwIter == 0)
	{
		SetDlgItemText(IDC_STC_MENU, "");
		pwIter++;
	}
	else if(*pwIter == 0xFFFF)
	{
		pwIter++;
		SetDlgItemInt(IDC_STC_MENU, *pwIter);
		pwIter++;
	}
	else
	{
		INT nUniLen = wcslen((LPWSTR)pwIter);
		INT nNameLen = CResAnalyzerApp::
			ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
								szMenu, sizeof(szMenu));
		if(!nNameLen)
		{
			CResAnalyzerApp::ShowErrorMessage(GetLastError());
			return;
		}
		SetDlgItemText(IDC_STC_MENU, szMenu);
		pwIter += (nUniLen + 1);
	}

	CHAR szClass[MAX_PATH] = { 0 };
	if(*pwIter)
	{
		INT nUniLen = wcslen((LPWSTR)pwIter);
		INT nNameLen = CResAnalyzerApp::
			ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
								szClass, sizeof(szClass));
		if(!nNameLen)
		{
			CResAnalyzerApp::ShowErrorMessage(GetLastError());
			return;
		}
		SetDlgItemText(IDC_STC_CLASS, szClass);
		pwIter += (nUniLen + 1);
	}
	else
	{
		SetDlgItemText(IDC_STC_CLASS, "");
		pwIter++;
	}

	CHAR szCaption[MAX_PATH] = { 0 };
	if(*pwIter)
	{
		INT nUniLen = wcslen((LPWSTR)pwIter);
		INT nNameLen = CResAnalyzerApp::
			ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
								szCaption, sizeof(szCaption));
		if(!nNameLen)
		{
			CResAnalyzerApp::ShowErrorMessage(GetLastError());
			return;
		}
		SetDlgItemText(IDC_STC_CAPTION, szCaption);
		pwIter += (nUniLen + 1);
	}
	else
	{
		SetDlgItemText(IDC_STC_CAPTION, "");
		pwIter++;
	}

	if(m_bIsExt)
		szTemp.Format("Ȯ�� ��ȭ���� ���� (����ID : %d)", dwHelpID); 
	else
		szTemp.Format("ǥ�� ��ȭ���� ����");
	SetDlgItemText(IDC_GRP_DLG, szTemp);

	if(bHasFont)
	{
		SetDlgItemInt(IDC_STC_POINT, *pwIter);
		pwIter++;
		SetDlgItemInt(IDC_STC_WEIGHT, *pwIter);
		pwIter++;
		SetDlgItemInt(IDC_STC_ITALYC, (*pwIter) & 0xFF);
		szTemp.Format("0x%02X", ((*pwIter) & 0xFF00)>>8);
		SetDlgItemText(IDC_STC_CHAR, szTemp);
		pwIter++;

		CHAR szFont[MAX_PATH];
		INT nUniLen = wcslen((LPWSTR)pwIter);
		INT nNameLen = CResAnalyzerApp::
			ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
								szFont, sizeof(szFont));
		if(!nNameLen)
		{
			CResAnalyzerApp::ShowErrorMessage(GetLastError());
			return;
		}
		pwIter += (nUniLen + 1);
		szTemp.Format("��Ʈ (%s)", szFont);
		SetDlgItemText(IDC_GRP_FONT, szTemp);
	}
	else
	{
		SetDlgItemText(IDC_STC_POINT, "");
		SetDlgItemText(IDC_STC_WEIGHT, "");
		SetDlgItemText(IDC_STC_ITALYC, "");
		SetDlgItemText(IDC_STC_CHAR, "");

		SetDlgItemText(IDC_GRP_FONT, "��Ʈ (���� ����)");
	}

	CString szID, szCls, szTitle, szXY, szWH;
	CString szStyle, szStyleEx, szParam, szHelpID;
	for(INT i=0; i<nCtrlCnt; i++)
	{
		LPBYTE pCtrlIter = (LPBYTE)DWORD_ALIGN(pwIter);
		
		if(m_bIsExt)
		{
			LPDLGITEMTEMPLATEEX pItem = (LPDLGITEMTEMPLATEEX)pCtrlIter;
			pCtrlIter += sizeof(DLGITEMTEMPLATEEX);
			szID.Format("%d", pItem->id);					pLv->InsertItem(i, szID);
			szXY.Format("(%d, %d)", pItem->x, pItem->y);	pLv->SetItemText(i, 3, szXY);
			szWH.Format("(%d, %d)", pItem->cx, pItem->cy);	pLv->SetItemText(i, 4, szWH);
			szStyle.Format("0x%08X", pItem->style);			pLv->SetItemText(i, 5, szStyle);
			szStyleEx.Format("0x%08X", pItem->exStyle);		pLv->SetItemText(i, 6, szStyleEx);
			szHelpID.Format("%d", pItem->helpID);			pLv->SetItemText(i, 8, szHelpID);
		}
		else
		{
			LPDLGITEMTEMPLATE pItem = (LPDLGITEMTEMPLATE)pCtrlIter;
			pCtrlIter += sizeof(DLGITEMTEMPLATE);
			szID.Format("%d", pItem->id);						pLv->InsertItem(i, szID);
			szXY.Format("(%d, %d)", pItem->x, pItem->y);		pLv->SetItemText(i, 3, szXY);
			szWH.Format("(%d, %d)", pItem->cx, pItem->cy);		pLv->SetItemText(i, 4, szWH);
			szStyle.Format("0x%08X", pItem->style);				pLv->SetItemText(i, 5, szStyle);
			szStyleEx.Format("0x%08X", pItem->dwExtendedStyle);	pLv->SetItemText(i, 6, szStyleEx);
			szHelpID = "-";										pLv->SetItemText(i, 8, szHelpID);
		}

		if(m_bIsExt)
			pwIter = DWORD_ALIGN(pCtrlIter);
		else
			pwIter = (LPWORD)pCtrlIter;
		// ��Ʈ�� Ŭ����
		if(*pwIter == 0)
		{
			szCls = "";
			pwIter++;
		}
		else if(*pwIter == 0xFFFF)
		{
			pwIter++;
			switch(*pwIter)
			{
				case 0x0080 : szCls = "BUTTON"   ; break;
				case 0x0081	: szCls = "EDIT"     ; break;
				case 0x0082	: szCls = "STATIC"   ; break;
				case 0x0083	: szCls = "LISTBOX"  ; break;
				case 0x0084	: szCls = "SCROLLBAR"; break;
				case 0x0085	: szCls = "COMBOBOX" ; break;
				default		: szCls.Format("0x%04X", *pwIter); break;
			}
			pwIter++;
		}
		else
		{
			INT nUniLen = wcslen((LPWSTR)pwIter);
			INT nNameLen = CResAnalyzerApp::
				ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
									szClass, sizeof(szClass));
			if(!nNameLen)
			{
				CResAnalyzerApp::ShowErrorMessage(GetLastError());
				return;
			}
			szCls = szClass;
			pwIter += (nUniLen + 1);
		}
		pLv->SetItemText(i, 1, szCls);

		// ��Ʈ�� Ÿ��Ʋ
		if(*pwIter == 0)
		{
			szTitle = "";
			pwIter++;
		}
		else if(*pwIter == 0xFFFF)
		{
			pwIter++;
			szTitle.Format("ID : %d (0x%04X)", *pwIter, *pwIter);
			pwIter++;
		}
		else
		{
			INT nUniLen = wcslen((LPWSTR)pwIter);
			INT nNameLen = CResAnalyzerApp::
				ConvertUniToMbcStr((LPWSTR)pwIter, nUniLen, 
									szCaption, sizeof(szCaption));
			if(!nNameLen)
			{
				CResAnalyzerApp::ShowErrorMessage(GetLastError());
				return; 
			}
			szTitle = szCaption;
			pwIter += (nUniLen + 1);
		}
		pLv->SetItemText(i, 2, szTitle);

		// ���� ������
		if(*pwIter == 0)
		{
			szParam = "����";
			pwIter++;
		}
		else
		{
			WORD wItemLen = *pwIter;
			szParam.Format("%d ����Ʈ", *pwIter);
			LPBYTE pTemp = (LPBYTE)pwIter;
			pTemp += wItemLen;
			pwIter = (LPWORD)pTemp;
		}
		pLv->SetItemText(i, 7, szParam);
	}
}

BOOL CResDialogDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CListCtrl* pLv = (CListCtrl*)GetDlgItem(IDC_LV_CTRL);
	DWORD dwExStyle = LVS_EX_FLATSB		  |		//��� ��ũ�ѹ�
					  LVS_EX_GRIDLINES	  |		//�׸��� ���̱�
					  LVS_EX_FULLROWSELECT;		//���� ��ü ����
	pLv->SetExtendedStyle(
			pLv->GetExtendedStyle()|dwExStyle);
	pLv->InsertColumn(0, "ID", LVCFMT_LEFT, 30);
	pLv->InsertColumn(1, "Ŭ����",	 LVCFMT_LEFT  , 100);
	pLv->InsertColumn(2, "Ÿ��Ʋ",	 LVCFMT_LEFT  , 120);
	pLv->InsertColumn(3, "X, Y",	 LVCFMT_CENTER,  60);
	pLv->InsertColumn(4, "W, H",	 LVCFMT_CENTER,  60);
	pLv->InsertColumn(5, "��Ÿ��",	 LVCFMT_CENTER,  75);
	pLv->InsertColumn(6, "��Ÿ��2",	 LVCFMT_CENTER,  75);
	pLv->InsertColumn(7, "��������", LVCFMT_LEFT  ,  40);
	pLv->InsertColumn(8, "����ID",	 LVCFMT_LEFT  ,  40);

	ParseDialogTemplate(pLv);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CResDialogDlg::OnLvnGetdispinfoLvCtrl(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	*pResult = 0;
}
