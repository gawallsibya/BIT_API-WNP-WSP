// ResAnalyzerDlg.h : ��� ����
//

#pragma once

struct RES_ITEM
{
	DWORD	_dwOffset;
	INT		_nDepth;
	union
	{
		struct
		{
			DWORD _wId   : 16;
			DWORD _dwRes : 15;
			DWORD _bIsId :  1;
		};
		DWORD_PTR _pszResName;
	};
	PIMAGE_RESOURCE_DATA_ENTRY _pEntry;

	RES_ITEM()
	{
		_dwOffset	= 0;
		_nDepth		= 0;
		_pszResName	= 0;
		_pEntry		= NULL;
	}
	~RES_ITEM()
	{
		if(!_bIsId)
			delete ((LPSTR)_pszResName);
		if(_pEntry)
			delete _pEntry;
	}
};
typedef RES_ITEM* PRES_ITEM;

// CResAnalyzerDlg ��ȭ ����
class CResAnalyzerDlg : public CDialog
{
// ����
public:
	CResAnalyzerDlg(CWnd* pParent = NULL);	// ǥ�� ������

// ��ȭ ���� ������
	enum { IDD = IDD_RESANALYZER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����

	CString m_szPeName;
	HANDLE	m_hImgFile;
	HANDLE	m_hImgMap;
	LPBYTE	m_pImgView;

	DWORD	m_dwResImg;
	INT		m_nDelta;

	INT			m_nDW;
	INT			m_nDH;
	CFont		m_tvFont;
	CBitmap		m_ImgItems[4];
	CImageList	m_ImgList;

	CTreeCtrl* Tv() { return (CTreeCtrl*)GetDlgItem(IDC_TV_RESINFO); }
	HTREEITEM AddItem(PRES_ITEM, HTREEITEM, HTREEITEM);

	void RecursiveResDir(DWORD, INT, WORD, HTREEITEM, HTREEITEM);
	void CleanUp();

// ����
protected:
	HICON m_hIcon;

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnTvnGetdispinfoTvResinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMDblclkTvResinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnImage();
	afx_msg void OnDestroy();
	afx_msg void OnTvnDeleteitemTvResinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};
