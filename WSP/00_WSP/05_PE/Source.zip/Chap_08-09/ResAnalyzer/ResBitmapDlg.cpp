// ResBitmapDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "ResAnalyzer.h"
#include "ResBitmapDlg.h"
#include ".\resbitmapdlg.h"


// CResBitmapDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CResBitmapDlg, CDialog)
CResBitmapDlg::CResBitmapDlg(LPBYTE pImgStart, UINT uType, CWnd* pParent /*=NULL*/)
	: CDialog(CResBitmapDlg::IDD, pParent)
{
	m_pImgStart		= pImgStart;
	m_uType			= uType;
	m_bIsCompressed = false;
}

CResBitmapDlg::~CResBitmapDlg()
{
}

void CResBitmapDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CResBitmapDlg, CDialog)
	ON_WM_PAINT()
END_MESSAGE_MAP()


// CResBitmapDlg �޽��� ó�����Դϴ�.
void CResBitmapDlg::ParseBitmap(CEdit* pEdit)
{
	CString szInfo;
	CString szTemp;

	LPBYTE pIter = m_pImgStart;

	if(m_uType == IMG_CURSOR)
	{
		WORD wHspX = *((LPWORD)pIter); pIter += sizeof(WORD);
		WORD wHspY = *((LPWORD)pIter); pIter += sizeof(WORD);
		szTemp.Format("�ֽ���      : (%d, %d)\xd\xa", wHspX, wHspX);
		szInfo += szTemp;
	}

	LPBITMAPINFOHEADER pBMI = (LPBITMAPINFOHEADER)pIter;
	pIter += sizeof(BITMAPINFOHEADER);

	szTemp.Format("��� ũ��   : %d (0x%08X)\xd\xa", pBMI->biSize, pBMI->biSize);
	szInfo += szTemp;
	szTemp.Format("�̹��� �ʺ� : %d (0x%08X)\xd\xa", pBMI->biWidth, pBMI->biWidth);
	szInfo += szTemp;
	szTemp.Format("�̹��� ���� : %d (0x%08X)\xd\xa", pBMI->biHeight, pBMI->biHeight);
	szInfo += szTemp;
	szTemp.Format("�÷��� ��   : %d (0x%04X)\xd\xa", pBMI->biPlanes, pBMI->biPlanes);
	szInfo += szTemp;
	szTemp.Format("�÷� ��Ʈ�� : %d (0x%04X)\xd\xa", pBMI->biBitCount, pBMI->biBitCount);
	szInfo += szTemp;
	szTemp.Format("����        : %d (0x%08X)\xd\xa", pBMI->biCompression, pBMI->biCompression);
	szInfo += szTemp;
	szTemp.Format("�̹��� ũ�� : %d (0x%08X)\xd\xa", pBMI->biSizeImage, pBMI->biSizeImage);
	szInfo += szTemp;
	szTemp.Format("X P/M       : %d (0x%08X)\xd\xa", pBMI->biXPelsPerMeter, pBMI->biXPelsPerMeter);
	szInfo += szTemp;
	szTemp.Format("Y P/M       : %d (0x%08X)\xd\xa", pBMI->biYPelsPerMeter, pBMI->biYPelsPerMeter);
	szInfo += szTemp;
	szTemp.Format("���� �÷� : %d (0x%08X)\xd\xa", pBMI->biClrUsed, pBMI->biClrUsed);
	szInfo += szTemp;
	szTemp.Format("�ֿ� �÷�   : %d (0x%08X)", pBMI->biClrImportant, pBMI->biClrImportant);
	szInfo += szTemp;

	pEdit->SetWindowText(szInfo);
	
	m_bIsCompressed = (pBMI->biCompression != 0);
	if(m_bIsCompressed)
		AfxMessageBox("�̹����� ����Ǿ� �ֽ��ϴ�. �̹��� ����� ���� �ʽ��ϴ�.");
}

LONG CResBitmapDlg::GetStorageWidth(LONG lWidth, WORD wBitCnt)
{
	LONG lStorageWidth = 0;

	switch(wBitCnt)
	{
		case 1	:
			if(lWidth & 7)
				lStorageWidth = (lWidth >> 3) + (((lWidth & 7) + 3) & ~3);
			else
				lStorageWidth = (((lWidth >> 3) + 3) & ~3);
		break;
		case 4	:
			lStorageWidth = lWidth >> 1;
			if((lWidth & 7) == 1)
				lStorageWidth += 4;
			else if(lWidth & 7)
				lStorageWidth = ((lStorageWidth + 3)& ~3);
		break;
		case 8	:
			lStorageWidth = ((lWidth + 3) & ~3);
		break;
		case 16	:
			lStorageWidth = ((lWidth * 2 + 3) & ~3);
		break;
		case 24	:
			lStorageWidth = ((lWidth * 3 + 3) & ~3);
		break;
		case 32	:
			lStorageWidth = lWidth << 2;
		break;
	}

	return lStorageWidth;
}

COLORREF CResBitmapDlg::GetPixelColor(LONG x, LONG y, WORD wBitCnt, 
									  LONG lStorageWidth, LONG lHeight, 
									  LPBYTE pRawBits, LPRGBQUAD pRgbPal)
{
	COLORREF clrPixel = 0;
	LONG	 lBasePos, lBitOffset, lColorIdx;
	BYTE	 byMask;
	WORD	 wPackClr;

	switch(wBitCnt)
	{
		case 1:
			lBasePos = (lHeight - y - 1) * lStorageWidth + (x >> 3);
			lBitOffset = 7 - (x & 7);
			byMask = 1 << lBitOffset;
			lColorIdx = (pRawBits[lBasePos] & byMask) >> lBitOffset;
			clrPixel = RGB(pRgbPal[lColorIdx].rgbRed, 
						   pRgbPal[lColorIdx].rgbGreen, 
						   pRgbPal[lColorIdx].rgbBlue);
		break;
		case 4:
			lBasePos = (lHeight - y - 1) * lStorageWidth + (x >> 1);
			lBitOffset = (1 - (x & 1)) << 2;
			byMask = 0x0F << lBitOffset;
			lColorIdx = (pRawBits[lBasePos] & byMask) >> lBitOffset;
			clrPixel = RGB(pRgbPal[lColorIdx].rgbRed, 
						   pRgbPal[lColorIdx].rgbGreen, 
						   pRgbPal[lColorIdx].rgbBlue);
		break;
		case 8:
			lBasePos = (lHeight - y - 1) * lStorageWidth + x;
			lColorIdx = pRawBits[lBasePos];
			clrPixel = RGB(pRgbPal[lColorIdx].rgbRed, 
						   pRgbPal[lColorIdx].rgbGreen, 
						   pRgbPal[lColorIdx].rgbBlue);
		break;
		case 16:
		{
			lBasePos = (lHeight - y - 1) * lStorageWidth + x * 2;
			wPackClr = *((LPWORD)(pRawBits + lBasePos));
			clrPixel = RGB((((wPackClr & 0x7C00) >>10) << 3), 
						   (((wPackClr & 0x03E0) >> 5) << 3), 
						    ((wPackClr & 0x001F) << 3)     ); 
		}
		break;
		case 24:
			lBasePos = (lHeight - y - 1) * lStorageWidth + x * 3;
			clrPixel = RGB(pRawBits[lBasePos + 2], 
						   pRawBits[lBasePos + 1], 
						   pRawBits[lBasePos    ]); 
		break;
		case 32:
			lBasePos = (lHeight - y - 1) * lStorageWidth + x * 4;
			clrPixel = RGB(pRawBits[lBasePos + 2], 
						   pRawBits[lBasePos + 1], 
						   pRawBits[lBasePos    ]); 
		break;
	}

	return clrPixel;
}

void CResBitmapDlg::DrawBitmap(CDC* pDC)
{
	LPBYTE pIter = m_pImgStart;

	if(m_uType == IMG_CURSOR)
		pIter += sizeof(DWORD);
	LPBITMAPINFOHEADER pBMI = (LPBITMAPINFOHEADER)pIter;
	pIter += sizeof(BITMAPINFOHEADER);

	INT nClrCnt = (pBMI->biBitCount > 0 && pBMI->biBitCount <= 8) ? 
											(1 << pBMI->biBitCount) : 0;
	LPRGBQUAD pRgbPal = (LPRGBQUAD)pIter;
	pIter += sizeof(RGBQUAD) * nClrCnt;

	CRect rc;
	GetDlgItem(IDC_STC_SHOWBMP)->GetWindowRect(rc);
	ScreenToClient(rc);

	CRgn rgnClip;
	rgnClip.CreateRectRgn(rc.left, rc.top, rc.right, rc.bottom);
	pDC->SelectClipRgn(&rgnClip);

	INT nSX = rc.left + 1;
	INT nSY = rc.top  + 1;

	LPBYTE pRawBits = pIter;
	LONG lStorageWidth = 
		GetStorageWidth(pBMI->biWidth, pBMI->biBitCount);
	LONG lHeight = 
		(m_uType == IMG_BITMAP) ? pBMI->biHeight : (pBMI->biHeight >> 1);
	for(LONG y=0; y < lHeight; y++)
	{
		for(LONG x=0; x<pBMI->biWidth; x++)
		{
			COLORREF clrPixel = GetPixelColor(x, y, pBMI->biBitCount, 
						lStorageWidth, lHeight, pRawBits, pRgbPal);
			pDC->SetPixel(nSX + x, nSY + y, clrPixel);
		}
	}
	if(m_uType == IMG_BITMAP)
		return;

	pRawBits += (lStorageWidth * lHeight);
	nSX += (pBMI->biWidth + 5);

	lStorageWidth = GetStorageWidth(pBMI->biWidth, 1);	
	RGBQUAD rqMono[2] = { 0, 0, 0, 0, 255, 255, 255, 255 };
	for(LONG y = 0; y < lHeight; y++)
	{
		for(LONG x = 0; x < pBMI->biWidth; x++)
		{
			COLORREF clrPixel = GetPixelColor(x, y, 1, lStorageWidth, 
											lHeight, pRawBits, rqMono);
			pDC->SetPixel(nSX + x, nSY + y, clrPixel);
		}
	}
}

void CResBitmapDlg::DrawPalette(CDC* pDC)
{
	LPBYTE pIter = m_pImgStart;

	if(m_uType == IMG_CURSOR)
		pIter += sizeof(DWORD);
	LPBITMAPINFOHEADER pBMI = (LPBITMAPINFOHEADER)pIter;
	pIter += sizeof(BITMAPINFOHEADER);

	if(!pBMI->biBitCount || pBMI->biBitCount > 8)
		return;

	INT nClrCnt = (1 << pBMI->biBitCount);
	LPRGBQUAD pRgbPal = (LPRGBQUAD)pIter;
	pIter += sizeof(RGBQUAD) * nClrCnt;

	CRect rc;
	GetDlgItem(IDC_EDT_BMPINFO)->GetWindowRect(rc);
	ScreenToClient(rc);

	CRect rcClr;
	bool bIsEnd = false;

	rcClr.top = rc.top;
	for(int j=0; j<8; j++)
	{
		rcClr.bottom = rcClr.top + 10;
		rcClr.left = rc.right + 10;

		for(int i=0; i<32; i++)
		{
			int nClrIdx = j * 32 + i;
			if(nClrIdx >= nClrCnt)
			{
				bIsEnd = true;
				break;
			}

			rcClr.right = rcClr.left + 10;

			CBrush br(RGB(pRgbPal[nClrIdx].rgbRed,
				pRgbPal[nClrIdx].rgbGreen, pRgbPal[nClrIdx].rgbBlue));
			CBrush* pOldBr = pDC->SelectObject(&br);
			pDC->Rectangle(rcClr);
			pDC->SelectObject(pOldBr);

			rcClr.left = rcClr.right-1;
		}
		if(bIsEnd)
			break;
		rcClr.top = rcClr.bottom - 1;
	}
}

BOOL CResBitmapDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CString szTitle = "�۽�...";
	if(m_uType == IMG_BITMAP)
		szTitle = " ��Ʈ�� ���ҽ� ����";
	else 
	if(m_uType == IMG_ICON)
		szTitle = " ������ ���ҽ� ����";
	else 
	if(m_uType == IMG_CURSOR)
		szTitle = " Ŀ�� ���ҽ� ����";
	SetWindowText(szTitle);

	ParseBitmap((CEdit*)GetDlgItem(IDC_EDT_BMPINFO));

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

void CResBitmapDlg::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	DrawPalette(&dc);
	if(!m_bIsCompressed)
		DrawBitmap(&dc);
}
