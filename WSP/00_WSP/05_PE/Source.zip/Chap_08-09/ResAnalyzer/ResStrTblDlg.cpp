// ResStrTblDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "ResAnalyzer.h"
#include "ResStrTblDlg.h"


// CResStrTblDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CResStrTblDlg, CDialog)
CResStrTblDlg::CResStrTblDlg(LPBYTE pImgStart, UINT uResID, 
							 DWORD dwItemSize, CWnd* pParent /*=NULL*/)
	: CDialog(CResStrTblDlg::IDD, pParent)
{
	m_pImgStart	 = pImgStart;
	m_uResID	 = uResID;
	m_dwItemSize = dwItemSize;
}

CResStrTblDlg::~CResStrTblDlg()
{
}

void CResStrTblDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CResStrTblDlg, CDialog)
END_MESSAGE_MAP()

// CResStrTblDlg �޽��� ó�����Դϴ�.

BOOL CResStrTblDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetDlgItemInt(IDC_EDT_RESID, m_uResID);

	CListCtrl* pLv = (CListCtrl*)GetDlgItem(IDC_LV_STRTBL);
	DWORD dwExStyle = LVS_EX_FLATSB		  |		//��� ��ũ�ѹ�
					  LVS_EX_GRIDLINES	  |		//�׸��� ���̱�
					  LVS_EX_FULLROWSELECT;		//���� ��ü ����
	pLv->SetExtendedStyle(
			pLv->GetExtendedStyle()|dwExStyle);
	pLv->InsertColumn(0, "ID", LVCFMT_CENTER, 100);
	pLv->InsertColumn(1, "���ڿ�", LVCFMT_LEFT, 300);

	ParseStringTable();

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CResStrTblDlg::ParseStringTable()
{
	CListCtrl* pLv = (CListCtrl*)GetDlgItem(IDC_LV_STRTBL);

	LPWORD pwResStrTbl = (LPWORD)m_pImgStart;
	for(INT i=0; i<16; i++)
	{
		if(pwResStrTbl[i] != 0)
			break;
	}

	DWORD dwSize = i*2;
	UINT uBaseID = (m_uResID - 1) * 16 + i;
	UINT uIter = 0;
	LPWSTR pwszIter = (LPWSTR)&pwResStrTbl[i];

	INT nItem = 0;
	while(dwSize < m_dwItemSize)
	{
		WORD wStrLen = (WORD)pwszIter[0];
		pwszIter++;
		dwSize += sizeof(WORD);
		if(!wStrLen)
		{
			uIter++;
			continue;
		}

		LPSTR pszResName = new CHAR[wStrLen*2 + 1];
		int nConvLen = WideCharToMultiByte(CP_ACP, 0, pwszIter, 
					wStrLen, pszResName, (wStrLen*2 + 1), NULL, NULL);
		if(!nConvLen)
		{
			CResAnalyzerApp::ShowErrorMessage(GetLastError());
			return;
		}
		pszResName[nConvLen] = 0x00;
		pwszIter += wStrLen;
		dwSize += (wStrLen * sizeof(WCHAR));

		CString szOut;
		szOut.Format("%d (0x%X)", uBaseID + uIter, uBaseID + uIter);
		pLv->InsertItem(nItem, szOut);
		pLv->SetItemText(nItem, 1, pszResName);
		delete pszResName;

		uIter++;
		nItem++;
	}
}
