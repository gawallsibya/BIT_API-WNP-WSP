//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ResAnalyzer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RESANALYZER_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDB_RES_ROOT                    129
#define IDB_RES_TYPE                    130
#define IDD_RES_STRTBL                  130
#define IDB_RES_NODE                    131
#define IDD_RES_ACCELTBL                131
#define IDB_RES_LEAF                    132
#define IDD_RES_BITMAP                  132
#define IDD_RES_DIALOG                  133
#define IDD_RES_MENU                    134
#define IDC_TV_RESINFO                  1000
#define IDC_BTN_IMAGE                   1001
#define IDC_EDT_IMAGE                   1002
#define IDC_LV_STRTBL                   1004
#define IDC_LV_ACCELTBL                 1005
#define IDC_EDT_BMPINFO                 1006
#define IDC_STC_SHOWBMP                 1007
#define IDC_BTN_SHOW_PARSE              1009
#define IDC_BTN_SHOW_DIALOG             1010
#define IDC_LV_CTRL                     1011
#define IDC_GRP_DLG                     1013
#define IDC_GRP_FONT                    1014
#define IDC_STC_CAPTION                 1015
#define IDC_STC_MENU                    1016
#define IDC_STC_CLASS                   1017
#define IDC_STC_XY                      1018
#define IDC_STC_WH                      1019
#define IDC_STC_STYLE                   1020
#define IDC_STC_STYLEEX                 1021
#define IDC_STC_POINT                   1022
#define IDC_STC_WEIGHT                  1023
#define IDC_STC_ITALYC                  1024
#define IDC_STC_CHAR                    1025
#define IDC_TV_MENU                     1026
#define IDC_EDT_RESID                   1027
#define IDC_BTN_SHOW_MAIN               1028
#define IDC_BTN_SHOW_POPUP              1029
#define IDC_EDIT1                       1030
#define IDC_EDT_INFO                    1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
