#pragma once

#define IMG_CURSOR	1
#define IMG_BITMAP	2
#define IMG_ICON	3

// CResBitmapDlg ��ȭ �����Դϴ�.

class CResBitmapDlg : public CDialog
{
	DECLARE_DYNAMIC(CResBitmapDlg)

	LPBYTE	m_pImgStart;
	UINT	m_uType;
	bool	m_bIsCompressed;

	void ParseBitmap(CEdit*);
	void DrawBitmap(CDC* pDC);
	void DrawPalette(CDC* pDC);
	LONG GetStorageWidth(LONG, WORD);
	COLORREF GetPixelColor(LONG, LONG, 
		WORD, LONG, LONG, LPBYTE, LPRGBQUAD);

public:
	CResBitmapDlg(LPBYTE, UINT, CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CResBitmapDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_RES_BITMAP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
};
