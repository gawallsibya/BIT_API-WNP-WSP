// ResAccelTblDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "ResAnalyzer.h"
#include "ResAccelTblDlg.h"
#include ".\resacceltbldlg.h"

struct ACCELTABLEENTRY
{ 
	WORD fFlags; 
	WORD wAnsi; 
	WORD wId; 
	WORD padding; 
};
typedef ACCELTABLEENTRY* LPACCELTABLEENTRY;

#define FEND		0x80

// CResAccelTblDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CResAccelTblDlg, CDialog)
CResAccelTblDlg::CResAccelTblDlg(LPBYTE pImgStart, CWnd* pParent /*=NULL*/)
	: CDialog(CResAccelTblDlg::IDD, pParent)
{
	m_pImgStart	 = pImgStart;
}

CResAccelTblDlg::~CResAccelTblDlg()
{
}

void CResAccelTblDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CResAccelTblDlg, CDialog)
END_MESSAGE_MAP()


// CResAccelTblDlg �޽��� ó�����Դϴ�.
void CResAccelTblDlg::ParseAccelatorTable(CListCtrl* pLv)
{
	LPCSTR pszKey[] = 
	{
		"BS", "Tab", "", "Clr", "Enter", "", "Shift", 
		"Ctrl", "Alt", "Pause", "CAPS", "Kana", "Han", 
		"", "Junja", "Final", "Hanja", "Kanji", "", 
		"Esc", "Ime","NoIme", "ImeChg", "Space", "PgUp", 
		"PgDn", "End", "Home", "Left", "Up", "Right", 
		"Down", "Sel", "Prn", "Exec", "PrnScrn", "Ins", 
		"Del", "Help"
	};
	bool	bIsNext = true;
	INT		nItem = 0;
	LPBYTE	pIter = m_pImgStart;

	do
	{
		LPACCELTABLEENTRY pATE = (LPACCELTABLEENTRY)pIter;
		pIter += sizeof(ACCELTABLEENTRY);

		CString szNum;
		szNum.Format("%d (0x%X)", pATE->wId, pATE->wId);
		pLv->InsertItem(nItem, szNum);

		if(pATE->wAnsi >= VK_BACK && pATE->wAnsi <= VK_HELP)
			szNum = pszKey[pATE->wAnsi - VK_BACK];
		else
		if(pATE->wAnsi >= VK_F1 && pATE->wAnsi <= VK_F24)
			szNum.Format("F%c", pATE->wAnsi - VK_F1 + 0x31);
		else
		if(pATE->wAnsi >= 0x30 && pATE->wAnsi <= 0x5A)
			szNum.Format("%c", pATE->wAnsi);
		else
			szNum = "������";
		pLv->SetItemText(nItem, 1, szNum);

		szNum.Empty();
		if(pATE->fFlags & FSHIFT)
			szNum += "Shift";
		if(pATE->fFlags & FCONTROL)
		{
			if(szNum.IsEmpty())
				szNum += "Ctrl";
			else
				szNum += " + Ctrl";
		}
		if(pATE->fFlags & FALT)
		{
			if(szNum.IsEmpty())
				szNum += "Alt";
			else
				szNum += " + Alt";
		}
		pLv->SetItemText(nItem, 2, szNum);

		if(pATE->fFlags & FVIRTKEY)
			szNum = "v";
		else
			szNum = "-";
		pLv->SetItemText(nItem, 3, szNum);

		if(pATE->fFlags & FNOINVERT)
			szNum = "No Invert";
		else
			szNum = "";
		if(pATE->fFlags & FEND)
		{
			if(szNum.IsEmpty())
				szNum += "Last Entry";
			else
				szNum += ", Last Entry";

			bIsNext = false;
		}
		pLv->SetItemText(nItem, 4, szNum);

		nItem++;
	}
	while(bIsNext);
}

BOOL CResAccelTblDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CListCtrl* pLv = (CListCtrl*)GetDlgItem(IDC_LV_ACCELTBL);
	DWORD dwExStyle = LVS_EX_FLATSB		  |		//��� ��ũ�ѹ�
					  LVS_EX_GRIDLINES	  |		//�׸��� ���̱�
					  LVS_EX_FULLROWSELECT;		//���� ��ü ����
	pLv->SetExtendedStyle(
			pLv->GetExtendedStyle()|dwExStyle);
	pLv->InsertColumn(0, "ID", LVCFMT_LEFT, 100);
	pLv->InsertColumn(1, "Ű�ڵ�", LVCFMT_CENTER, 50);
	pLv->InsertColumn(2, "����Ű", LVCFMT_LEFT, 60);
	pLv->InsertColumn(3, "����Ű", LVCFMT_CENTER, 50);
	pLv->InsertColumn(4, "��Ÿ", LVCFMT_LEFT, 150);

	ParseAccelatorTable(pLv);

	return TRUE;  // return TRUE unless you set the focus to a control
	// ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}
