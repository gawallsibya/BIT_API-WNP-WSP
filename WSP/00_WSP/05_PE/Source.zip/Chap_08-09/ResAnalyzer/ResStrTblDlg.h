#pragma once


// CResStrTblDlg ��ȭ �����Դϴ�.

class CResStrTblDlg : public CDialog
{
	DECLARE_DYNAMIC(CResStrTblDlg)

	LPBYTE	m_pImgStart;
	UINT	m_uResID;
	DWORD	m_dwItemSize;

	void ParseStringTable();

public:
	CResStrTblDlg(LPBYTE, UINT, DWORD, CWnd* pParent = NULL);
	virtual ~CResStrTblDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_RES_STRTBL };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
};
