// ResMenuDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "ResAnalyzer.h"
#include "ResMenuDlg.h"
#include ".\resmenudlg.h"


// CResMenuDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CResMenuDlg, CDialog)
CResMenuDlg::CResMenuDlg(LPBYTE pImgStart, CWnd* pParent /*=NULL*/)
	: CDialog(CResMenuDlg::IDD, pParent)
{
	m_pImgStart = pImgStart;
}

CResMenuDlg::~CResMenuDlg()
{
}

void CResMenuDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

void CResMenuDlg::ParseMenuItems()
{
	Tv()->DeleteAllItems();

	TV_INSERTSTRUCT tvis ;
	ZeroMemory(&(tvis.item), sizeof(TVITEM));
	tvis.item.mask		= TVIF_TEXT|TVIF_PARAM|TVIF_HANDLE;
	tvis.item.pszText	= LPSTR_TEXTCALLBACK;
	tvis.item.cChildren	= 1;
	tvis.item.lParam	= (LPARAM)0;
	tvis.hParent		= TVI_ROOT;
	tvis.hInsertAfter	= TVI_LAST;

	HTREEITEM hRoot = Tv()->InsertItem(&tvis);
	LPBYTE pIter = m_pImgStart + sizeof(DWORD);
	MakeMenuTree(pIter, hRoot);
}

void CResMenuDlg::MakeMenuTree(LPBYTE& pIter, HTREEITEM hParent)
{
	LPSTR pszMenuText = NULL;

	try
	{
		bool bIsExit = false;
		do
		{
			PMENU_ITEM pMenu = new MENU_ITEM();

			pMenu->_wAttr = *((LPWORD)pIter);
			pIter += sizeof(WORD);

			if(pMenu->_wAttr & MF_END)
				bIsExit = true;

			UINT_PTR uidItem = 0;
			if(!(pMenu->_wAttr & MF_POPUP))
			{
				uidItem = (UINT_PTR)(*((LPWORD)pIter));
				pMenu->_wID = uidItem;
				pIter += sizeof(WORD);
			}

			INT nUniLen = wcslen((LPWSTR)pIter);
			if(nUniLen)
			{
				INT nNameLen = CResAnalyzerApp::ConvertUniToMbcStr
					((LPWSTR)pIter, nUniLen, pMenu->_szName, sizeof(pMenu->_szName));
				if(!nNameLen)
				{
					CResAnalyzerApp::ShowErrorMessage(GetLastError());
					return;
				}
			}
			else
			{
				if(!pMenu->_wAttr && !uidItem)
					strcpy(pMenu->_szName, "------------------");
			}
			pIter += (nUniLen + 1)*2;

			TV_INSERTSTRUCT tvis ;
			ZeroMemory(&(tvis.item), sizeof(TVITEM));
			tvis.item.mask		= TVIF_TEXT|TVIF_PARAM|TVIF_HANDLE;
			tvis.item.pszText	= LPSTR_TEXTCALLBACK;
			tvis.item.cChildren	= 1;
			tvis.item.lParam	= (LPARAM)pMenu;
			tvis.hParent		= hParent;
			tvis.hInsertAfter	= TVI_LAST;

			HTREEITEM hItem = Tv()->InsertItem(&tvis);
			if(!hItem)
				throw GetLastError();

			if(pMenu->_wAttr & MF_POPUP)
				MakeMenuTree(pIter, hItem);
		}
		while(!bIsExit);
	}
	catch(HRESULT hr)
	{
		CResAnalyzerApp::ShowErrorMessage(hr);
	}
}

PMENU_ITEM CResMenuDlg::FindItem(CTreeCtrl* pTree, HTREEITEM hItem, WORD wID)
{
	HTREEITEM hTemp = pTree->GetChildItem(hItem);
	while(hTemp)
	{
		PMENU_ITEM pMenu = (PMENU_ITEM)pTree->GetItemData(hTemp);
		if(pMenu->_wAttr & MF_POPUP)
		{
			pMenu = FindItem(pTree, hTemp, wID);
			if(pMenu)
				return pMenu;
		}
		else
		{
			if(pMenu->_wID == wID)
				return pMenu;
		}
		hTemp = pTree->GetNextSiblingItem(hTemp);
	}

	return NULL;
}

LRESULT CALLBACK MenuWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static HMENU		s_hMenu;
	static CTreeCtrl*	s_pTree;

	switch(uMsg)
	{
		case WM_CREATE :
		{
			LPCREATESTRUCT pCS = (LPCREATESTRUCT)lParam;
			PCREATE_PRM pPrm = (PCREATE_PRM)pCS->lpCreateParams;
			s_hMenu = pPrm->_hMenu;
			s_pTree = pPrm->_pTree;
		}
		return TRUE;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			RECT        rc;

			CString szOut;
			if(s_hMenu)
				szOut = "���콺 ������ ��ư�� Ŭ���� �ּ���!!!";
			else
				szOut = "�ָ޴��� ������ �ּ���!!!";
			HDC hDC = BeginPaint(hWnd, &ps);
			GetClientRect(hWnd, &rc);
			DrawText(hDC, 
					 szOut, 
					 szOut.GetLength(), 
					 &rc, 
					 DT_SINGLELINE|DT_CENTER|DT_VCENTER);
			EndPaint (hWnd, &ps) ;
		}
		return 0;

		case WM_CONTEXTMENU	:
		{
			if(s_hMenu)
			{
				TrackPopupMenu(s_hMenu, TPM_LEFTALIGN|TPM_LEFTBUTTON , 
					LOWORD(lParam), HIWORD(lParam), 0, hWnd, NULL);
				return 0;
			}
		}
		break;

		case WM_DESTROY:
			//PostQuitMessage(0);
		return 0;

		case WM_COMMAND :
		{
			if(!HIWORD(wParam))
			{
				WORD id = LOWORD(wParam);
				HTREEITEM hRoot = s_pTree->GetRootItem();
				PMENU_ITEM pMenu = CResMenuDlg::FindItem(s_pTree, hRoot, id);

				CString szOut;
				if(pMenu)
					szOut.Format("%s [ID : %d] �޴��� ���õǾ����ϴ�.", 
						pMenu->_szName, pMenu->_wID);
				else
					szOut.Format("ID %d �޴� �׸��� �������� �ʽ��ϴ�", id);
				AfxMessageBox(szOut);
				return 0;
			}
		}
		break;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

void CResMenuDlg::ShowParsedMenu(bool bIsMain)
{
	LPCSTR pcszClsName = "TEST_MENU";
	LPBYTE pIter = m_pImgStart;
	WORD wVersion = *((LPWORD)pIter); pIter += sizeof(WORD);
	WORD wcbSize  = *((LPWORD)pIter); pIter += sizeof(WORD);

	if(wVersion || wcbSize)
	{
	}

	HMENU hMenu = MakeMenuItem(pIter, bIsMain);
	if(hMenu)
	{
		HWND         hWnd;
		WNDCLASS     wndclass;

		////////////////////////////////////////////////////////////////////////////
		//�������� Ŭ���� ���
		////////////////////////////////////////////////////////////////////////////
		wndclass.style         = CS_HREDRAW|CS_VREDRAW;
		wndclass.lpfnWndProc   = MenuWndProc;
		wndclass.cbClsExtra    = 0;
		wndclass.cbWndExtra    = 0;
		wndclass.hInstance     = AfxGetInstanceHandle();
		wndclass.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
		wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
		wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
		wndclass.lpszMenuName  = NULL;
		wndclass.lpszClassName = pcszClsName;
		if(!RegisterClass(&wndclass))
		{
			//::MessageBox(NULL, TEXT("Window Class Registeration Failure!!!"),
			//		"TEST_MENU", MB_ICONERROR) ;
			//return;
		}
		////////////////////////////////////////////////////////////////////////////


		////////////////////////////////////////////////////////////////////////////
		//�������� ����& ����
		////////////////////////////////////////////////////////////////////////////
		CREATE_PRM cp;
		cp._hMenu = (bIsMain) ? NULL : hMenu;
		cp._pTree = (CTreeCtrl*)GetDlgItem(IDC_TV_MENU);
		hWnd = CreateWindow(pcszClsName, pcszClsName, WS_OVERLAPPEDWINDOW,
							CW_USEDEFAULT, CW_USEDEFAULT, 400, 150, 
							AfxGetMainWnd()->GetSafeHwnd(),	
							(bIsMain) ? hMenu : NULL, 
							AfxGetInstanceHandle(),	&cp);
		if(!hWnd)
		{
			::MessageBox(NULL, TEXT("Window Creation Failure!!!"),
					"TEST_MENU", MB_ICONERROR) ;
			return;
		}
		::ShowWindow(hWnd, SW_NORMAL);
		::UpdateWindow(hWnd);
		////////////////////////////////////////////////////////////////////////////

		//MSG msg;
		//for(;;)
		//{
		//	if(PeekMessage(&msg, hWnd, 0, 0, PM_REMOVE))
		//	{
		//		if(msg.message == WM_QUIT)
		//			break;
		//		TranslateMessage(&msg);
		//		DispatchMessage(&msg);
		//	}
		//}
	}
}

HMENU CResMenuDlg::MakeMenuItem(LPBYTE& pIter, bool bIsRoot)
{
	LPSTR pszMenuText = NULL;
	HMENU hMenu = (bIsRoot) ? CreateMenu() : CreatePopupMenu();

	try
	{
		bool bIsExit = false;
		do
		{
			WORD wAttr = *((LPWORD)pIter);
			pIter += sizeof(WORD);

			if(wAttr & MF_END)
			{
				wAttr &= ~MF_END;
				bIsExit = true;
			}

			UINT_PTR uidItem = 0;
			if(!(wAttr & MF_POPUP))
			{
				uidItem = (UINT_PTR)(*((LPWORD)pIter));
				pIter += sizeof(WORD);
			}

			INT nUniLen = wcslen((LPWSTR)pIter);
			if(nUniLen)
			{
				pszMenuText = new CHAR[(nUniLen + 1) * 2];
				INT nNameLen = CResAnalyzerApp::ConvertUniToMbcStr
					((LPWSTR)pIter, nUniLen, pszMenuText, (nUniLen + 1) * 2);
				if(!nNameLen)
					throw GetLastError();
			}
			else
			{
				if(!wAttr && !uidItem)
					wAttr = MF_SEPARATOR;
			}
			pIter += (nUniLen + 1) * 2;

			if(wAttr & MF_POPUP)
				uidItem = (UINT_PTR)MakeMenuItem(pIter, false);

			BOOL bIsOK;
			if(wAttr == MF_SEPARATOR)
				bIsOK = AppendMenu(hMenu, wAttr, uidItem, "");
			else
				bIsOK = AppendMenu(hMenu, wAttr, uidItem, pszMenuText);
			if(!bIsOK)
				throw GetLastError();

			if(pszMenuText)
			{
				delete pszMenuText;
				pszMenuText = NULL;
			}
		}
		while(!bIsExit);
	}
	catch(HRESULT hr)
	{
		if(pszMenuText)
			delete pszMenuText;

		if(hMenu)
		{
			DestroyMenu(hMenu);
			hMenu = NULL;
		}
		CResAnalyzerApp::ShowErrorMessage(hr);
	}

	return hMenu;
}

BEGIN_MESSAGE_MAP(CResMenuDlg, CDialog)
	ON_NOTIFY(TVN_GETDISPINFO, IDC_TV_MENU, OnTvnGetdispinfoTvMenu)
	ON_BN_CLICKED(IDC_BTN_SHOW_MAIN, OnBnClickedBtnShowMain)
	ON_BN_CLICKED(IDC_BTN_SHOW_POPUP, OnBnClickedBtnShowPopup)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TV_MENU, OnTvnSelchangedTvMenu)
	ON_NOTIFY(TVN_DELETEITEM, IDC_TV_MENU, OnTvnDeleteitemTvMenu)
	ON_WM_DESTROY()
END_MESSAGE_MAP()

// CResMenuDlg �޽��� ó�����Դϴ�.

void CResMenuDlg::OnTvnGetdispinfoTvMenu(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTVDISPINFO ptvdi = reinterpret_cast<LPNMTVDISPINFO>(pNMHDR);
	PMENU_ITEM pMenu = (PMENU_ITEM)(ptvdi->item.lParam);

	CString szFormat;
	if(!pMenu)
		szFormat = "�޴�";
	else
		szFormat = pMenu->_szName;
	strcpy(ptvdi->item.pszText, szFormat);

	*pResult = 0;
}

void CResMenuDlg::OnBnClickedBtnShowMain()
{
	ShowParsedMenu(true);
}

void CResMenuDlg::OnBnClickedBtnShowPopup()
{
	ShowParsedMenu(false);
}

BOOL CResMenuDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	ParseMenuItems();

	return TRUE;  // ��Ʈ�ѿ� ���� ��Ŀ���� �������� ���� ��� TRUE�� ��ȯ�մϴ�.
}

void CResMenuDlg::OnTvnSelchangedTvMenu(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pnmtv = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	PMENU_ITEM pMenu = (PMENU_ITEM)pnmtv->itemNew.lParam;

	CString szOut;
	if(pMenu)
	{
		if(pMenu->_wAttr & MF_POPUP)
			szOut.Format("�˾��޴�\xd\xa"
				"=====================\xd\xa%s\xd\xa", pMenu->_szName);
		else
			szOut.Format("�Ϲݸ޴�\xd\xa=====================\xd\xa"
			"%s\xd\xaID : %d (0x%08X)\xd\xa", pMenu->_szName, 
			pMenu->_wID, pMenu->_wID);

		if(pMenu->_wAttr & MF_CHECKED)
			szOut += "üũ��\xd\xa";
		if(pMenu->_wAttr & MF_DISABLED)
			szOut += "��Ȱ��\xd\xa";
		if(pMenu->_wAttr & MF_GRAYED)
			szOut += "�׷���\xd\xa";
	}
	GetDlgItem(IDC_EDT_INFO)->SetWindowText(szOut);
		
	*pResult = 0;
}

void CResMenuDlg::OnTvnDeleteitemTvMenu(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);

	if(pNMTreeView->itemOld.lParam)
	{
		delete ((PMENU_ITEM)pNMTreeView->itemOld.lParam);
		pNMTreeView->itemOld.lParam = 0;
	}

	*pResult = 0;
}

void CResMenuDlg::OnDestroy()
{
	CDialog::OnDestroy();

	Tv()->DeleteAllItems();
}
