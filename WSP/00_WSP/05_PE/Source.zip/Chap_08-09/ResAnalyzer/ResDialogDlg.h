#pragma once


// CResDialogDlg ��ȭ �����Դϴ�.

class CResDialogDlg : public CDialog
{
	DECLARE_DYNAMIC(CResDialogDlg)

	LPBYTE	m_pImgStart;
	bool	m_bIsExt;

	static LRESULT CALLBACK DlgProc(HWND, UINT, WPARAM, LPARAM);
	static LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

	void CResDialogDlg::ParseDialogTemplate(CListCtrl*);

public:
	CResDialogDlg(LPBYTE, CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CResDialogDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_RES_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedBtnShowParse();
	afx_msg void OnBnClickedBtnShowDialog();
	virtual BOOL OnInitDialog();
	afx_msg void OnLvnGetdispinfoLvCtrl(NMHDR *pNMHDR, LRESULT *pResult);
};
