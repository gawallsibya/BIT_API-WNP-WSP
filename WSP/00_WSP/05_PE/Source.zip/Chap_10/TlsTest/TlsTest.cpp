#include <Windows.h>
#include <StdIo.h>

__declspec(thread) DWORD gt_dwTlsVal = 2000;

DWORD WINAPI ThreadProc(LPVOID)
{
	for(int i=0; i<1000; i++)
		gt_dwTlsVal--;

	printf("Thread #%d : gt_dwTlsVal is %d\n", 
		GetCurrentThreadId(), gt_dwTlsVal);

	return 0;
}

void main()
{
	HANDLE hThread;
	DWORD  dwThreadId;

	hThread = CreateThread(NULL, 0, ThreadProc, NULL, 0, &dwThreadId);

	for(int i=0; i<1000; i++)
		gt_dwTlsVal += 2;

	WaitForSingleObject(hThread, INFINITE);

	printf("Thread #%d : gt_dwTlsVal is %d\n", 
		GetCurrentThreadId(), gt_dwTlsVal);
}
