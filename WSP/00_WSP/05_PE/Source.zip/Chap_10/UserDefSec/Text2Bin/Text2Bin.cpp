// Text2Bin.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//
#include "stdafx.h"
#include <Windows.h>
#include "Resource.h"

int _tmain(int argc, _TCHAR* argv[])
{
	LPCSTR	pszSource = argv[1];
	CHAR	szTarget[MAX_PATH];

	wsprintf(szTarget, "%s.exe", pszSource);

	HANDLE hSource = CreateFile(pszSource, GENERIC_READ, 
		FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
	HANDLE hTarget = CreateFile(szTarget, GENERIC_WRITE, 
		0, NULL, OPEN_ALWAYS, 0, NULL);

	BYTE	abyText[65536];
	DWORD	dwReadBytes;
	ReadFile(hSource, abyText, sizeof(abyText), &dwReadBytes, NULL);

	HRSRC hBinRes = FindResource(GetModuleHandle(NULL), 
		MAKEINTRESOURCE(IDR_BIN_VIEW), "BINARY");
	HGLOBAL hBin = LoadResource(GetModuleHandle(NULL), hBinRes);
	INT		nSize = 106496;	//(INT)GlobalSize(hBin);
	LPBYTE	pBin = (LPBYTE)LockResource(hBin);

	PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)pBin;
	PIMAGE_NT_HEADERS pNt = (PIMAGE_NT_HEADERS)(pBin + pDos->e_lfanew);
	LPBYTE pIter = pBin + pDos->e_lfanew + sizeof(IMAGE_NT_HEADERS);
	PIMAGE_SECTION_HEADER pSec = NULL;
	for(int i=0; i<pNt->FileHeader.NumberOfSections; i++)
	{
		pSec = (PIMAGE_SECTION_HEADER)pIter;
		pIter += sizeof(IMAGE_SECTION_HEADER);

		if(!memcmp(pSec->Name, ".YHD", 4))
			break;
	}
	if(i == pNt->FileHeader.NumberOfSections)
	{
	}
	memcpy(pBin + pSec->PointerToRawData, abyText, dwReadBytes);

	DWORD	dwWroteBytes;
	WriteFile(hTarget, pBin, nSize, &dwWroteBytes, NULL);

	UnlockResource(hBin);

	CloseHandle(hTarget);
	CloseHandle(hSource);

	return 0;
}
