// PEHdrAnalyzerDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "PEHdrAnalyzer.h"
#include "PEHdrAnalyzerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ���� ���α׷� ������ ���Ǵ� CAboutDlg ��ȭ �����Դϴ�.

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ȭ ���� ������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ����

// ����
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CPEHdrAnalyzerDlg ��ȭ ����



CPEHdrAnalyzerDlg::CPEHdrAnalyzerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPEHdrAnalyzerDlg::IDD, pParent)
	, m_szPeName(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_hImgFile	= INVALID_HANDLE_VALUE;
	m_hImgMap	= NULL;
	m_pImgView	= NULL;
}

void CPEHdrAnalyzerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDT_IMAGE, m_szPeName);
}

BEGIN_MESSAGE_MAP(CPEHdrAnalyzerDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_NOTIFY(NM_DBLCLK, IDC_TV_PEHDR, OnNMDblclkTvPehdr)
	ON_NOTIFY(TVN_GETDISPINFO, IDC_TV_PEHDR, OnTvnGetdispinfoTvPehdr)
	ON_BN_CLICKED(IDC_BTN_IMAGE, OnBnClickedBtnImage)
	ON_WM_DESTROY()
	ON_WM_SIZE()
END_MESSAGE_MAP()


// CPEHdrAnalyzerDlg �޽��� ó����

BOOL CPEHdrAnalyzerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �ý��� �޴��� "����..." �޴� �׸��� �߰��մϴ�.

	// IDM_ABOUTBOX�� �ý��� ���� ������ �־�� �մϴ�.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	// �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	// TODO: ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	m_tvFont.CreatePointFont(90, "����ü");
	Tv()->SetFont(&m_tvFont);

	CRect rcp;
	GetWindowRect(rcp);
	CRect rcc;
	GetClientRect(rcc);

	CRect rct;
	Tv()->GetWindowRect(rct);
	m_nDW = (rct.left - rcp.left + 1) - ((rcp.Width() - rcc.Width())>>1);
	m_nDH = (rct.top - rcp.top + 1) - (rcp.Height() - rcc.Height());
	
	return TRUE;  // ��Ʈ�ѿ� ���� ��Ŀ���� �������� ���� ��� TRUE�� ��ȯ�մϴ�.
}

void CPEHdrAnalyzerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸����� 
// �Ʒ� �ڵ尡 �ʿ��մϴ�. ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
// �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void CPEHdrAnalyzerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�. 
HCURSOR CPEHdrAnalyzerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CPEHdrAnalyzerDlg::OnNMDblclkTvPehdr(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CPEHdrAnalyzerDlg::OnTvnGetdispinfoTvPehdr(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTVDISPINFO pTVDispInfo = reinterpret_cast<LPNMTVDISPINFO>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CPEHdrAnalyzerDlg::OnBnClickedBtnImage()
{
	TCHAR szDefExt[] = "exe";
	TCHAR szFilter[] = "���� ���ø����̼�(*.exe)|*.exe|"
		"���� ���̺귯��(*.dll)|*.dll|��� ����(*.*)|*.*||";

	CFileDialog dlg(TRUE, szDefExt, "", 
		OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	if(dlg.DoModal() != IDOK)
		return;

	CleanUp();

	m_szPeName = dlg.GetPathName();
	try
	{
		m_hImgFile = CreateFile(m_szPeName, GENERIC_READ, FILE_SHARE_READ,
								NULL, OPEN_EXISTING, 0,NULL);
		if(m_hImgFile == INVALID_HANDLE_VALUE)
			throw MAKE_HRESULT(1, FACILITY_WIN32, GetLastError());

		m_hImgMap = CreateFileMapping(m_hImgFile, NULL, 
									  PAGE_READONLY, 0, 0, NULL);
		if(!m_hImgMap)
			throw MAKE_HRESULT(1, FACILITY_WIN32, GetLastError());

		m_pImgView = (LPBYTE)MapViewOfFile(m_hImgMap, FILE_MAP_READ, 0, 0, 0);
		if(!m_pImgView)
			throw MAKE_HRESULT(1, FACILITY_WIN32, GetLastError());


		HTREEITEM hRoot = Tv()->InsertItem(m_szPeName);

		DWORD dwOffset = 0;

		PIMAGE_DOS_HEADER pIDH = (PIMAGE_DOS_HEADER)m_pImgView;
		if(pIDH->e_magic != IMAGE_DOS_SIGNATURE)
			throw "PE ������ ���� ������ �ƴմϴ�";

		CString szItem;
		szItem.Format("[%08X] IMAGE_DOS_HEADER", dwOffset);
		HTREEITEM h1stChild = Tv()->InsertItem(szItem, hRoot);
		dwOffset = ParseDosHdr(dwOffset, h1stChild);

		dwOffset = pIDH->e_lfanew;
		PIMAGE_NT_HEADERS pINH = (PIMAGE_NT_HEADERS)(m_pImgView + dwOffset);
		if(pINH->Signature != IMAGE_NT_SIGNATURE)
			throw "PE ������ ���� ������ �ƴմϴ�";
		szItem.Format("[%08X] IMAGE_NT_HEADERS", dwOffset);
		h1stChild = Tv()->InsertItem(szItem, hRoot);
		dwOffset = ParseNTHdrs(dwOffset, h1stChild);

		szItem.Format("[%08X] IMAGE_SECTIION_HEADER ���̺�", dwOffset);
		h1stChild = Tv()->InsertItem(szItem, hRoot);
		dwOffset = ParseSectionHdrs(dwOffset, 
			(INT)pINH->FileHeader.NumberOfSections, h1stChild);

	}
	catch(HRESULT hr)
	{
		CleanUp();
		CPEHdrAnalyzerApp::ShowErrorMessage(hr);
	}
	catch(LPCSTR pszMsg)
	{
		CleanUp();
		AfxMessageBox(pszMsg);
	}

	UpdateData(FALSE);
}

void CPEHdrAnalyzerDlg::CleanUp()
{
	Tv()->DeleteAllItems();

	if(m_pImgView)
	{
		UnmapViewOfFile(m_pImgView);
		m_pImgView = NULL;
	}
	if(m_hImgMap)
	{
		CloseHandle(m_hImgMap);
		m_hImgMap	= NULL;
	}
	if(m_hImgFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hImgFile);
		m_hImgFile	= INVALID_HANDLE_VALUE;
	}

	m_szPeName.Empty();
}


void CPEHdrAnalyzerDlg::OnDestroy()
{
	CDialog::OnDestroy();

	CleanUp();
}

void CPEHdrAnalyzerDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	if(Tv()->GetSafeHwnd())
	{
		cx -= ( m_nDW * 2 );
		cy -= ( m_nDH + m_nDW);
		Tv()->SetWindowPos(NULL, 0, 0, cx, cy, SWP_NOMOVE|SWP_NOZORDER);
	}
}

DWORD CPEHdrAnalyzerDlg::ParseDosHdr(DWORD dwOffset, HTREEITEM hParent)
{
	LPCSTR pcszFld[] =
	{
		"e_magic   ", "e_cblp    ", "e_cp      ", "e_crlc    ", "e_cparhdr ",
		"e_minalloc", "e_maxalloc", "e_ss      ", "e_sp      ", "e_csum    ",
		"e_ip      ", "e_cs      ", "e_lfarlc  ", "e_ovno    ", "e_res[4]  ",
		"e_oemid   ", "e_oeminfo ", "e_res2[10]", "e_lfanew  "
	};
	INT anSize[] = 
	{
		sizeof(WORD), sizeof(WORD), sizeof(WORD), sizeof(WORD), sizeof(WORD), 
		sizeof(WORD), sizeof(WORD), sizeof(WORD), sizeof(WORD), sizeof(WORD), 
		sizeof(WORD), sizeof(WORD), sizeof(WORD), sizeof(WORD), sizeof(WORD)*4, 
		sizeof(WORD), sizeof(WORD), sizeof(WORD)*10, sizeof(LONG)
	};

	LPBYTE pIter = m_pImgView + dwOffset;
	INT nIterCnt = sizeof(pcszFld) / sizeof(LPCSTR);
	for(INT i=0; i<nIterCnt; i++)
	{
		CString szItem;

		if(i == 14 || i == 15)
			szItem.Format("[%08X] %s size is WORD * %d", 
				dwOffset, pcszFld[i], anSize[i]/sizeof(WORD));
		else
		{
			if(i == nIterCnt - 1)
				szItem.Format("[%08X] %s 0x%08X", dwOffset, pcszFld[i], *((LPLONG)pIter));
			else
				szItem.Format("[%08X] %s 0x%04X", dwOffset, pcszFld[i], *((LPWORD)pIter));

		}

		HTREEITEM hItem = Tv()->InsertItem(szItem, hParent);
		pIter += anSize[i];
		dwOffset += anSize[i];
	}

	return dwOffset;
}

DWORD CPEHdrAnalyzerDlg::ParseNTHdrs(DWORD dwOffset, HTREEITEM hParent)
{
	LPBYTE pIter = m_pImgView + dwOffset;

	CString szItem;
	szItem.Format("[%08X] Signature  %08X", dwOffset, *((LPDWORD)pIter));
	HTREEITEM hNtHdrs = Tv()->InsertItem(szItem, hParent);
	dwOffset += sizeof(DWORD);

	szItem.Format("[%08X] IMAGE_FILE_HEADER", dwOffset);
	hNtHdrs = Tv()->InsertItem(szItem, hParent);
	dwOffset = ParseFileHdr(dwOffset, hNtHdrs);

	szItem.Format("[%08X] IMAGE_OPTIONAL_HEADER", dwOffset);
	hNtHdrs = Tv()->InsertItem(szItem, hParent);
	dwOffset = ParseOptionalHdr(dwOffset, hNtHdrs);

	return dwOffset;
}

DWORD CPEHdrAnalyzerDlg::ParseFileHdr(DWORD dwOffset, HTREEITEM hParent)
{
	LPCSTR pcszFld[] =
	{
		"Machine                ", "NumberOfSections       ", "TimeDateStamp          ", 
		"PointerToSymbolTable   ", "NumberOfSymbols        ", "SizeOfOptionalHeader   ", 
		"Characteristics        " 
	};
	INT anSize[] = 
	{
		sizeof(WORD ), sizeof(WORD ), sizeof(DWORD), sizeof(DWORD),
		sizeof(DWORD), sizeof(WORD ), sizeof(WORD )
	};

	LPBYTE pIter = m_pImgView + dwOffset;
	INT nIterCnt = sizeof(pcszFld) / sizeof(LPCSTR);
	for(INT i=0; i<nIterCnt; i++)
	{
		CString szItem;

		if(anSize[i] == sizeof(WORD))
			szItem.Format("[%08X] %s 0x%04X", dwOffset, pcszFld[i], *((LPWORD)pIter));
		else
		{
			szItem.Format("[%08X] %s 0x%08X", dwOffset, pcszFld[i], *((LPDWORD)pIter));
			if(i == 2)
			{
				// TimeDateStamp
				SYSTEMTIME st;
				FILETIME ft;
				ULARGE_INTEGER li;
				memset(&st, 0x00, sizeof(st));
				st.wYear = 1970, st.wMonth = 1, st.wDay = 1, st.wHour = 9;
				SystemTimeToFileTime(&st, &ft);
				li.HighPart = ft.dwHighDateTime;
				li.LowPart  = ft.dwLowDateTime;
				li.QuadPart += ((unsigned __int64)(*((LPDWORD)pIter)) * 10000000L);
				ft.dwHighDateTime = li.HighPart;
				ft.dwLowDateTime = li.LowPart;
				FileTimeToSystemTime(&ft, &st);

				CString szTime;
				szTime.Format(", %04d/%02d/%02d-%02d:%02d:%02d",
					st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
				szItem += szTime;
			}
		}

		HTREEITEM hItem = Tv()->InsertItem(szItem, hParent);
		pIter += anSize[i];
		dwOffset += anSize[i];
	}

	return dwOffset;
}

DWORD CPEHdrAnalyzerDlg::ParseOptionalHdr(DWORD dwOffset, HTREEITEM hParent)
{
	LPCSTR pcszFld[] =
	{
		"Magic                  ", "LinkerVersion          ", "SizeOfCode             ", 
		"SizeOfInitializedData  ", "SizeOfUninitializedData", "AddressOfEntryPoint    ", 
		"BaseOfCode             ", "BaseOfData             ", "ImageBase              ", 
		"SectionAlignment       ", "FileAlignment          ", "OperatingSystemVersion ", 
		"ImageVersion           ", "SubsystemVersion       ", "Win32VersionValue      ", 
		"SizeOfImage            ", "SizeOfHeaders          ", "CheckSum               ", 
		"Subsystem              ", "DllCharacteristics     ", "SizeOfStackReserve     ", 
		"SizeOfStackCommit      ", "SizeOfHeapReserve      ", "SizeOfHeapCommit       ", 
		"LoaderFlags            ", "NumberOfRvaAndSizes    "
	};
	INT anSize[] = 
	{
		sizeof(WORD ), sizeof(WORD ), sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), 
		sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), 
		sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), 
		sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), sizeof(WORD ), sizeof(WORD ), 
		sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), 
		sizeof(DWORD)
	};

	LPBYTE pIter = m_pImgView + dwOffset;
	INT nIterCnt = sizeof(pcszFld) / sizeof(LPCSTR);
	for(INT i=0; i<nIterCnt; i++)
	{
		CString szItem;

		if(i == 1)
			szItem.Format("[%08X] %s 0x%02X, 0x%02X(%d.%d)", 
				dwOffset, pcszFld[i], *pIter, 
				*(pIter + 1), *pIter, *(pIter + 1));
		else
		if(i == 11 || i == 12 || i == 13)
			szItem.Format("[%08X] %s 0x%04X, 0x%04X(%d.%d)", 
				dwOffset, pcszFld[i], 
				*((LPWORD)pIter), *((LPWORD)pIter + 1), 
				*((LPWORD)pIter), *((LPWORD)pIter + 1));
		else
		{
			if(anSize[i] == sizeof(WORD))
				szItem.Format("[%08X] %s 0x%04X", 
					dwOffset, pcszFld[i], *((LPWORD)pIter));
			else
				szItem.Format("[%08X] %s 0x%08X", 
					dwOffset, pcszFld[i], *((LPDWORD)pIter));
		}

		HTREEITEM hItem = Tv()->InsertItem(szItem, hParent);
		pIter += anSize[i];
		dwOffset += anSize[i];
	}

	CString szItem;
	szItem.Format("[%08X] IMAGE_DATA_DIRECTORY", dwOffset);
	HTREEITEM hItem = Tv()->InsertItem(szItem, hParent);
	dwOffset = ParseDataDir(dwOffset, hItem);

	return dwOffset;
}

DWORD CPEHdrAnalyzerDlg::ParseDataDir(DWORD dwOffset, HTREEITEM hParent)
{
	LPCSTR pcszFld[] =
	{
		"IMAGE_DIRECTORY_ENTRY_EXPORT        ",  //  0, Export Directory
		"IMAGE_DIRECTORY_ENTRY_IMPORT        ",  //  1, Import Directory
		"IMAGE_DIRECTORY_ENTRY_RESOURCE      ",  //  2, Resource Directory
		"IMAGE_DIRECTORY_ENTRY_EXCEPTION     ",  //  3, Exception Directory
		"IMAGE_DIRECTORY_ENTRY_SECURITY      ",  //  4, Security Directory
		"IMAGE_DIRECTORY_ENTRY_BASERELOC     ",  //  5, Base Relocation Table
		"IMAGE_DIRECTORY_ENTRY_DEBUG         ",  //  6, Debug Directory
		"IMAGE_DIRECTORY_ENTRY_ARCHITECTURE  ",  //  7, Architecture Specific Data
		"IMAGE_DIRECTORY_ENTRY_GLOBALPTR     ",  //  8, RVA of GP
		"IMAGE_DIRECTORY_ENTRY_TLS           ",  //  9, TLS Directory
		"IMAGE_DIRECTORY_ENTRY_LOAD_CONFIG   ",  // 10, Load Configuration Directory
		"IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT  ",  // 11, Bound Import Directory in headers
		"IMAGE_DIRECTORY_ENTRY_IAT           ",  // 12, Import Address Table
		"IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT  ",	 // 13, Delay Load Import Descriptors
		"IMAGE_DIRECTORY_ENTRY_COM_DESCRIPTOR",  // 14, COM Runtime descriptor
		"IMAGE_DIRECTORY_ENTRY_NULL          "   // 15, NULL
	};

	CString szItem;
	LPBYTE pIter = m_pImgView + dwOffset;
	for(int i=0; i<IMAGE_NUMBEROF_DIRECTORY_ENTRIES; i++)
	{
		PIMAGE_DATA_DIRECTORY pIDD = (PIMAGE_DATA_DIRECTORY)pIter;
		bool bIsNull = !(pIDD->Size || pIDD->VirtualAddress);

		szItem.Format("[%08X] %s[%02d][%c]", 
			dwOffset, pcszFld[i], i, bIsNull ? 'X' : 'O');
		HTREEITEM hItem = Tv()->InsertItem(szItem, hParent);
		if(!bIsNull)
		{
			szItem.Format("[%08X] VirtualAddress    0x%08X", 
				dwOffset, pIDD->VirtualAddress);
			HTREEITEM hIddFld = Tv()->InsertItem(szItem, hItem);
			dwOffset += sizeof(pIDD->VirtualAddress);
			szItem.Format("[%08X] Size              0x%08X", 
				dwOffset, pIDD->Size);
			hIddFld = Tv()->InsertItem(szItem, hItem);
			dwOffset += sizeof(pIDD->Size);
		}
		else
			dwOffset += sizeof(IMAGE_DATA_DIRECTORY);

		pIter += sizeof(IMAGE_DATA_DIRECTORY);
	}

	return dwOffset;
}

DWORD CPEHdrAnalyzerDlg::ParseSectionHdrs(DWORD dwOffset, INT nSecCnt, HTREEITEM hParent)
{
	LPCSTR pcszFld[] =
	{
		"VirtualSize            ", "VirtualAddress         ", "SizeOfRawData          ", 
		"PointerToRawData       ", "PointerToRelocations   ", "PointerToLinenumbers   ", 
		"NumberOfRelocations    ", "NumberOfLinenumbers    ", "Characteristics        "
	};
	INT anSize[] = 
	{
		sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), sizeof(DWORD), 
		sizeof(DWORD), sizeof(DWORD), sizeof(WORD ), sizeof(WORD ), sizeof(DWORD)
	};

	LPBYTE pIter = m_pImgView + dwOffset;
	for(INT i=0; i<nSecCnt; i++)
	{
		CString szItem;

		CHAR szSecName[9];
		memcpy(szSecName, pIter, IMAGE_SIZEOF_SHORT_NAME);
		szSecName[IMAGE_SIZEOF_SHORT_NAME] = 0x00;
		szItem.Format("[%08X] %-8s[%02d]", dwOffset, szSecName, i);
		HTREEITEM hSecHdr = Tv()->InsertItem(szItem, hParent);
		pIter += IMAGE_SIZEOF_SHORT_NAME;
		dwOffset += IMAGE_SIZEOF_SHORT_NAME;

		INT nIterCnt = sizeof(pcszFld) / sizeof(LPCSTR);
		for(INT j=0; j<nIterCnt; j++)
		{
			if(anSize[j] == sizeof(WORD))
				szItem.Format("[%08X] %s 0x%04X", dwOffset, pcszFld[j], *((LPWORD)pIter));
			else
				szItem.Format("[%08X] %s 0x%08X", dwOffset, pcszFld[j], *((LPDWORD)pIter));

			HTREEITEM hItem = Tv()->InsertItem(szItem, hSecHdr);
			pIter += anSize[j];
			dwOffset += anSize[j];
		}
	}

	return dwOffset;
}
