// PEHdrAnalyzerDlg.h : ��� ����
//

#pragma once


// CPEHdrAnalyzerDlg ��ȭ ����
class CPEHdrAnalyzerDlg : public CDialog
{
// ����
public:
	CPEHdrAnalyzerDlg(CWnd* pParent = NULL);	// ǥ�� ������

// ��ȭ ���� ������
	enum { IDD = IDD_PEHDRANALYZER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����

	CString m_szPeName;
	HANDLE	m_hImgFile;
	HANDLE	m_hImgMap;
	LPBYTE	m_pImgView;

// ����
protected:
	HICON m_hIcon;

	void CleanUp();
	CTreeCtrl* Tv() { return (CTreeCtrl*)GetDlgItem(IDC_TV_PEHDR); }

	DWORD ParseDosHdr(DWORD, HTREEITEM);
	DWORD ParseNTHdrs(DWORD, HTREEITEM);
	DWORD ParseFileHdr(DWORD, HTREEITEM);
	DWORD ParseOptionalHdr(DWORD, HTREEITEM);
	DWORD ParseDataDir(DWORD, HTREEITEM);
	DWORD ParseSectionHdrs(DWORD, INT, HTREEITEM);

	INT			m_nDW;
	INT			m_nDH;
	CFont		m_tvFont;

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnNMDblclkTvPehdr(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnGetdispinfoTvPehdr(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnImage();
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
};

