#include <Windows.h>

INT PseudoRelocation(LPBYTE pImageBase, DWORD dwNewBase)
{
	if(!pImageBase)
		return -1;

	PIMAGE_DOS_HEADER pIDH = (PIMAGE_DOS_HEADER)pImageBase;
	if(pIDH->e_magic != IMAGE_DOS_SIGNATURE)
		return -1;

	PIMAGE_NT_HEADERS pINH = (PIMAGE_NT_HEADERS)(pImageBase + pIDH->e_lfanew);
	if(pINH->Signature != IMAGE_NT_SIGNATURE)
		return -1;

	INT nDelta = (INT)(dwNewBase - pINH->OptionalHeader.ImageBase);

	PIMAGE_DATA_DIRECTORY pIDD = &pINH->
		OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
	if(!pIDD->VirtualAddress)
		return 0;

	PIMAGE_SECTION_HEADER pISH = (PIMAGE_SECTION_HEADER)
		(pImageBase + pIDH->e_lfanew + sizeof(IMAGE_NT_HEADERS));

	INT nRelDelta = 0;
	for(WORD wShCnt = 0; wShCnt < pINH->FileHeader.NumberOfSections; wShCnt++)
	{
		if(!memcmp(pISH[wShCnt].Name, ".reloc", strlen(".reloc")))
		{
			nRelDelta = (pISH[wShCnt].VirtualAddress - pISH[wShCnt].PointerToRawData);
			break;
		}
	}

	LPBYTE	pIter		= (pImageBase + pIDD->VirtualAddress - nRelDelta);
	INT		nRebaseCnt	= 0;
	DWORD	dwIterBytes	= 0;

	while(dwIterBytes < pIDD->Size)
	{
		PIMAGE_BASE_RELOCATION pIBR = (PIMAGE_BASE_RELOCATION)pIter;

		DWORD dwSecDelta = 0;
		PIMAGE_SECTION_HEADER pIshTbl = (PIMAGE_SECTION_HEADER)
			(pImageBase + pIDH->e_lfanew + sizeof(IMAGE_NT_HEADERS));
		for(INT i=0; i<pINH->FileHeader.NumberOfSections; i++)
		{
			if(	(pIBR->VirtualAddress >= pIshTbl[i].VirtualAddress) &&
				(pIBR->VirtualAddress <  pIshTbl[i].VirtualAddress + pIshTbl[i].Misc.VirtualSize))
				dwSecDelta = pIshTbl[i].VirtualAddress - pIshTbl[i].PointerToRawData;
		}
		LPBYTE pBaseAddr = (pImageBase + pIBR->VirtualAddress - dwSecDelta);
		pIter += IMAGE_SIZEOF_BASE_RELOCATION;
		dwIterBytes += IMAGE_SIZEOF_BASE_RELOCATION;
		
		LPWORD pwOffsetTbl = (LPWORD)pIter;
		INT nOffsetCnt = (INT)(pIBR->SizeOfBlock - 
			IMAGE_SIZEOF_BASE_RELOCATION) / sizeof(WORD);
		for(INT i=0; i<nOffsetCnt; i++)
		{
			if(pwOffsetTbl[i] & 0xF000)
			{
				DWORD dwOffset = (DWORD)(pwOffsetTbl[i] & 0x0FFF);
				*((LPINT)(pBaseAddr + dwOffset)) += nDelta;
			}
			pIter += sizeof(WORD);
			dwIterBytes += sizeof(WORD);
			nRebaseCnt++;
		}
	}

	pINH->OptionalHeader.ImageBase += nDelta;

	return nRebaseCnt;
}

void main(INT argc, LPCSTR argv[])
{
	LPCSTR pszImgName = argv[1];
	LPCSTR pNewBase = argv[2];
	DWORD dwNewBase = (DWORD)atoi(pNewBase);

	HANDLE hModFile = CreateFile(pszImgName, 
								 GENERIC_READ|GENERIC_WRITE, 
								 FILE_SHARE_READ|FILE_SHARE_WRITE,
								 NULL, 
								 OPEN_EXISTING, 
								 0,
								 NULL);
	HANDLE hModMap = CreateFileMapping(hModFile, 
									   NULL, 
									   PAGE_READWRITE, 
									   0, 0, NULL);
	LPBYTE pModView = (LPBYTE)MapViewOfFile(hModMap, 
											FILE_MAP_READ|FILE_MAP_WRITE, 
											0, 0, 0);

	INT nRebaseCnt = PseudoRelocation(pModView, dwNewBase);

	UnmapViewOfFile(pModView);
	CloseHandle(hModMap);
	CloseHandle(hModFile);
}
