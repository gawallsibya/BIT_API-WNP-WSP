// RelocAnalyzerDlg.h : ��� ����
//

#pragma once


// CRelocAnalyzerDlg ��ȭ ����
class CRelocAnalyzerDlg : public CDialog
{
// ����
public:
	CRelocAnalyzerDlg(CWnd* pParent = NULL);	// ǥ�� ������

// ��ȭ ���� ������
	enum { IDD = IDD_RELOCANALYZER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����

	CString m_szPeName;
	HANDLE	m_hImgFile;
	HANDLE	m_hImgMap;
	LPBYTE	m_pImgView;

	DWORD	m_dwRelocImg;
	INT		m_nDelta;

	INT		m_nDW;
	INT		m_nDH;
	CFont	m_tvFont;

	CTreeCtrl* Tv() { return (CTreeCtrl*)GetDlgItem(IDC_TV_RELOCINFO); }
	void CleanUp();

	void ParseBaseRelocationSection(DWORD, HTREEITEM);
	PIMAGE_SECTION_HEADER FindSection(DWORD, bool=false);

// ����
protected:
	HICON m_hIcon;

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnNMDblclkTvRelocinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnGetdispinfoTvRelocinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnDeleteitemTvRelocinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnImage();
};
