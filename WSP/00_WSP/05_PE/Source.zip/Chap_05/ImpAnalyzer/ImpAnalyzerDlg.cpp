// ImpAnalyzerDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "ImpAnalyzer.h"
#include "ImpAnalyzerDlg.h"
#include ".\impanalyzerdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ���� ���α׷� ������ ���Ǵ� CAboutDlg ��ȭ �����Դϴ�.

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ȭ ���� ������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ����

// ����
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CImpAnalyzerDlg ��ȭ ����



CImpAnalyzerDlg::CImpAnalyzerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CImpAnalyzerDlg::IDD, pParent)
	, m_szPeName(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_hImgFile	= INVALID_HANDLE_VALUE;
	m_hImgMap	= NULL;
	m_pImgView	= NULL;

	m_dwImpImg	= 0;
	m_nDtImp	= 0;
	m_dwBndImg	= 0;
	m_nDtBnd	= 0;
}

void CImpAnalyzerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDT_IMAGE, m_szPeName);
}

BEGIN_MESSAGE_MAP(CImpAnalyzerDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_NOTIFY(NM_DBLCLK, IDC_TV_IMPINFO, OnNMDblclkTvImpinfo)
	ON_NOTIFY(TVN_GETDISPINFO, IDC_TV_IMPINFO, OnTvnGetdispinfoTvImpinfo)
	ON_NOTIFY(TVN_DELETEITEM, IDC_TV_IMPINFO, OnTvnDeleteitemTvImpinfo)
	ON_BN_CLICKED(IDC_BTN_IMAGE, OnBnClickedBtnImage)
END_MESSAGE_MAP()


// CImpAnalyzerDlg �޽��� ó����

BOOL CImpAnalyzerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �ý��� �޴��� "����..." �޴� �׸��� �߰��մϴ�.

	// IDM_ABOUTBOX�� �ý��� ���� ������ �־�� �մϴ�.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	// �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	m_tvFont.CreatePointFont(90, "����ü");
	Tv()->SetFont(&m_tvFont);

	CRect rcp;
	GetWindowRect(rcp);
	CRect rcc;
	GetClientRect(rcc);

	CRect rct;
	Tv()->GetWindowRect(rct);
	m_nDW = (rct.left - rcp.left + 1) - ((rcp.Width() - rcc.Width())>>1);
	m_nDH = (rct.top - rcp.top + 1) - (rcp.Height() - rcc.Height());
	
	return TRUE;  // ��Ʈ�ѿ� ���� ��Ŀ���� �������� ���� ��� TRUE�� ��ȯ�մϴ�.
}

void CImpAnalyzerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸����� 
// �Ʒ� �ڵ尡 �ʿ��մϴ�. ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
// �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void CImpAnalyzerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�. 
HCURSOR CImpAnalyzerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CImpAnalyzerDlg::OnDestroy()
{
	CDialog::OnDestroy();

	CleanUp();
}

void CImpAnalyzerDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	if(Tv()->GetSafeHwnd())
	{
		cx -= ( m_nDW * 2 );
		cy -= ( m_nDH + m_nDW);
		Tv()->SetWindowPos(NULL, 0, 0, cx, cy, SWP_NOMOVE|SWP_NOZORDER);
	}
}

void CImpAnalyzerDlg::OnNMDblclkTvImpinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CImpAnalyzerDlg::OnTvnGetdispinfoTvImpinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTVDISPINFO pTVDispInfo = reinterpret_cast<LPNMTVDISPINFO>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CImpAnalyzerDlg::OnTvnDeleteitemTvImpinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CImpAnalyzerDlg::OnBnClickedBtnImage()
{
	TCHAR szDefExt[] = "exe";
	TCHAR szFilter[] = "���� ���ø����̼�(*.exe)|*.exe|"
		"���� ���̺귯��(*.dll)|*.dll|��� ����(*.*)|*.*||";

	CFileDialog dlg(TRUE, szDefExt, "", 
		OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	if(dlg.DoModal() != IDOK)
		return;

	CleanUp();

	m_szPeName = dlg.GetPathName();
	try
	{

		m_hImgFile = CreateFile(m_szPeName, GENERIC_READ, FILE_SHARE_READ,
								NULL, OPEN_EXISTING, 0,NULL);
		if(m_hImgFile == INVALID_HANDLE_VALUE)
			throw MAKE_HRESULT(1, FACILITY_WIN32, GetLastError());

		m_hImgMap = CreateFileMapping(m_hImgFile, NULL, 
									  PAGE_READONLY, 0, 0, NULL);
		if(!m_hImgMap)
			throw MAKE_HRESULT(1, FACILITY_WIN32, GetLastError());

		m_pImgView = (LPBYTE)MapViewOfFile(m_hImgMap, FILE_MAP_READ, 0, 0, 0);
		if(!m_pImgView)
			throw MAKE_HRESULT(1, FACILITY_WIN32, GetLastError());


		PIMAGE_DOS_HEADER pIDH = (PIMAGE_DOS_HEADER)m_pImgView;
		if(pIDH->e_magic != IMAGE_DOS_SIGNATURE)
			throw "PE ������ ���� ������ �ƴմϴ�";

		PIMAGE_NT_HEADERS pINH = (PIMAGE_NT_HEADERS)(m_pImgView + pIDH->e_lfanew);
		if(pINH->Signature != IMAGE_NT_SIGNATURE)
			throw "PE ������ ���� ������ �ƴմϴ�";


		PIMAGE_DATA_DIRECTORY pddImp = 
			&pINH->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
		if(!pddImp->Size && !pddImp->VirtualAddress)
			throw "����Ʈ ������ �������� �ʽ��ϴ�.";

		PIMAGE_DATA_DIRECTORY pddIat = 
			&pINH->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IAT];
		if(!pddIat->Size && !pddIat->VirtualAddress)
			throw "IAT�� �������� �ʽ��ϴ�.";

		PIMAGE_DATA_DIRECTORY pddBnd = 
			&pINH->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT];
		if(!pddBnd->Size && !pddBnd->VirtualAddress)
			pddBnd = NULL;

		DWORD dwDImp = 0, dwDBnd = 0;
		LPBYTE pIterSec = m_pImgView + pIDH->e_lfanew + sizeof(IMAGE_NT_HEADERS);
		PIMAGE_SECTION_HEADER pshImp = NULL, pshBnd = NULL;
		for(INT i=0; i<pINH->FileHeader.NumberOfSections; i++)
		{
			PIMAGE_SECTION_HEADER pTemp = (PIMAGE_SECTION_HEADER)pIterSec;
			pIterSec += sizeof(IMAGE_SECTION_HEADER);

			if(pddBnd && !pshBnd)
			{
				if(	(pddBnd->VirtualAddress >= pTemp->VirtualAddress) &&
					(pddBnd->VirtualAddress <= pTemp->VirtualAddress + 
											   pTemp->Misc.VirtualSize))
					pshBnd = pTemp;
			}

			if(!pshImp)
			{
				if(!memcmp(pTemp->Name, ".idata\x0\x0", IMAGE_SIZEOF_SHORT_NAME))
					pshImp = pTemp;
			}
		}
		if(!pshImp)
			throw "�ͽ���Ʈ ������ �������� �ʽ��ϴ�.";

		m_dwImpImg = pshImp->PointerToRawData;
		m_nDtImp = pshImp->VirtualAddress - m_dwImpImg;
		if(pddBnd)
		{
			if(pshBnd)
			{
				m_nDtBnd = pshBnd->VirtualAddress - pshBnd->PointerToRawData;
				m_dwBndImg = pddBnd->VirtualAddress - m_nDtBnd;
			}
			else
			{
				m_nDtBnd = 0;
				m_dwBndImg = pddBnd->VirtualAddress;
			}
		}

		CString szItem;
		szItem.Format("����Ʈ ����");
		HTREEITEM hRoot = Tv()->InsertItem(szItem, NULL);

		// ����Ʈ ���� �м�
		ParseImportSection(hRoot);
		// IAT �м�
		ParseIATBlock(pddIat, hRoot);
		// �ٿ�� ����Ʈ ���� �м�
		if(m_dwBndImg)
			ParseBoundSection(hRoot);
	}
	catch(HRESULT hr)
	{
		CleanUp();
		CImpAnalyzerApp::ShowErrorMessage(hr);
	}
	catch(LPCSTR pszMsg)
	{
		m_dwImpImg = 0;
		m_dwBndImg = 0;

		CleanUp();
		AfxMessageBox(pszMsg);
	}

	UpdateData(FALSE);
}

void CImpAnalyzerDlg::CleanUp()
{
	Tv()->DeleteAllItems();

	m_dwImpImg = 0;
	m_dwBndImg = 0;

	if(m_pImgView)
	{
		UnmapViewOfFile(m_pImgView);
		m_pImgView = NULL;
	}
	if(m_hImgMap)
	{
		CloseHandle(m_hImgMap);
		m_hImgMap	= NULL;
	}
	if(m_hImgFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hImgFile);
		m_hImgFile	= INVALID_HANDLE_VALUE;
	}

	m_szPeName.Empty();
}

void CImpAnalyzerDlg::ParseImportSection(HTREEITEM hRoot)
{
	CString	szItem;
	DWORD	dwOffset = m_dwImpImg;
	LPBYTE	pIter = m_pImgView + dwOffset;
	INT		nImpCnt = 0;

	szItem.Format("[%08X] ����Ʈ ���� ����", dwOffset);
	HTREEITEM hImpTbl = Tv()->InsertItem(szItem, hRoot);
	for(;;)
	{
		PIMAGE_IMPORT_DESCRIPTOR pIID = (PIMAGE_IMPORT_DESCRIPTOR)pIter;
		pIter += sizeof(IMAGE_IMPORT_DESCRIPTOR);
		if(!pIID->OriginalFirstThunk && !pIID->FirstThunk)
			break;

		// 
		szItem.Format("[%08X : %02d] IMAGE_IMPORT_DESCRIPTOR", dwOffset, nImpCnt);
		HTREEITEM hImport = Tv()->InsertItem(szItem, hImpTbl);
		dwOffset += sizeof(IMAGE_IMPORT_DESCRIPTOR);

		// OriginalFirstThunk
		szItem.Format("OriginalFirstThunk 0x%08X", pIID->OriginalFirstThunk);
		HTREEITEM hField = Tv()->InsertItem(szItem, hImport);
		szItem.Format("[%08X] INT(����Ʈ �̸� ���̺�)");
		HTREEITEM hInt = Tv()->InsertItem(szItem, hField);
		DWORD dwRawOffset = pIID->OriginalFirstThunk - m_nDtImp;
		LPDWORD pdwINT = (LPDWORD)(m_pImgView + dwRawOffset);
		for(int i=0; pdwINT[i]; i++)
		{
			szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwINT[i]);
			HTREEITEM hChild = Tv()->InsertItem(szItem, hInt);
			dwRawOffset += sizeof(DWORD);

			if(pdwINT[i] & 0x80000000)
			{
				WORD wOrdinal = (WORD)(pdwINT[i] & 0x0000FFFF);
				szItem.Format("[%08X] ���� %d", dwRawOffset, wOrdinal);
			}
			else
			{
				DWORD dwRawOffset2 = pdwINT[i] - m_nDtImp;
				PIMAGE_IMPORT_BY_NAME pIBN = (PIMAGE_IMPORT_BY_NAME)(m_pImgView + dwRawOffset2);
				szItem.Format("[%08X] Hint 0x%04d", dwRawOffset2, pIBN->Hint);
				dwRawOffset2 += sizeof(pIBN->Hint);
				Tv()->InsertItem(szItem, hChild);
				LPSTR pszFuncName = (LPSTR)&pIBN->Name;
				szItem.Format("[%08X] Name %s", dwRawOffset2, pszFuncName);
			}
			Tv()->InsertItem(szItem, hChild);
		}

		// TimeDateStamp
		szItem.Format("TimeDateStamp      0x%08X", pIID->TimeDateStamp);
		hField = Tv()->InsertItem(szItem, hImport);

		// ForwarderChain
		szItem.Format("ForwarderChain     0x%08X", pIID->ForwarderChain);
		hField = Tv()->InsertItem(szItem, hImport);

		// Name
		szItem.Format("Name               0x%08X", pIID->Name);
		hField = Tv()->InsertItem(szItem, hImport);
		dwRawOffset = pIID->Name - m_nDtImp;
		LPSTR pszDllName = (LPSTR)(m_pImgView + dwRawOffset);
		szItem.Format("[%08X] %s", dwRawOffset, pszDllName);
		HTREEITEM hChild = Tv()->InsertItem(szItem, hField);

		// FirstThunk
		szItem.Format("FirstThunk         0x%08X", pIID->FirstThunk);
		hField = Tv()->InsertItem(szItem, hImport);
		szItem.Format("[%08X] IAT(����Ʈ �ּ� ���̺�)");
		HTREEITEM hIat = Tv()->InsertItem(szItem, hField);
		dwRawOffset = pIID->FirstThunk - m_nDtImp;
		LPDWORD pdwIAT = (LPDWORD)(m_pImgView + dwRawOffset);
		for(i=0; pdwIAT[i]; i++)
		{
			szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwIAT[i]);
			HTREEITEM hChild = Tv()->InsertItem(szItem, hIat);
			dwRawOffset += sizeof(DWORD);
		}

		nImpCnt++;
	}
}

void CImpAnalyzerDlg::ParseBoundSection(HTREEITEM hRoot)
{
	CString	szItem;
	DWORD	dwOffset = m_dwBndImg;
	LPBYTE	pIter = m_pImgView + dwOffset;
	INT		nBndCnt = 0;

	szItem.Format("[%08X] �ٿ�� ����Ʈ ����", dwOffset);
	HTREEITEM hBndTbl = Tv()->InsertItem(szItem, hRoot);
	for(;;)
	{
		PIMAGE_BOUND_IMPORT_DESCRIPTOR pBID = (PIMAGE_BOUND_IMPORT_DESCRIPTOR)pIter;
		pIter += sizeof(IMAGE_BOUND_IMPORT_DESCRIPTOR);
		dwOffset += sizeof(IMAGE_BOUND_IMPORT_DESCRIPTOR);
		if(	!pBID->TimeDateStamp && !pBID->OffsetModuleName && 
			!pBID->NumberOfModuleForwarderRefs)
			break;

		// 
		szItem.Format("[%08X : %02d] IMAGE_BOUND_IMPORT_DESCRIPTOR", dwOffset, nBndCnt);
		HTREEITEM hBound = Tv()->InsertItem(szItem, hBndTbl);

		// TimeDateStamp
		SYSTEMTIME st;
		FILETIME ft;
		ULARGE_INTEGER li;
		memset(&st, 0x00, sizeof(st));
		st.wYear = 1970, st.wMonth = 1, st.wDay = 1, st.wHour = 9;
		SystemTimeToFileTime(&st, &ft);
		li.HighPart = ft.dwHighDateTime;
		li.LowPart  = ft.dwLowDateTime;
		li.QuadPart += ((unsigned __int64)pBID->TimeDateStamp * 10000000L);
		ft.dwHighDateTime = li.HighPart;
		ft.dwLowDateTime = li.LowPart;
		FileTimeToSystemTime(&ft, &st);
		szItem.Format("TimeDateStamp               0x%08X, "
			"%04d/%02d/%02d-%02d:%02d:%02d", pBID->TimeDateStamp, 
			st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
		HTREEITEM hField = Tv()->InsertItem(szItem, hBound);

		// OffsetModuleName
		szItem.Format("OffsetModuleName            0x%04X", pBID->OffsetModuleName);
		hField = Tv()->InsertItem(szItem, hBound);
		DWORD dwRawOffset = m_dwBndImg + pBID->OffsetModuleName;
		LPSTR pszDllName = (LPSTR)(m_pImgView + dwRawOffset);
		szItem.Format("[%08X] %s", dwRawOffset, pszDllName);
		HTREEITEM hChild = Tv()->InsertItem(szItem, hField);

		// NumberOfModuleForwarderRefs
		szItem.Format("NumberOfModuleForwarderRefs 0x%04X", pBID->NumberOfModuleForwarderRefs);
		hField = Tv()->InsertItem(szItem, hBound);
		if(pBID->NumberOfModuleForwarderRefs)
		{
			DWORD dwBFRStart = dwOffset;
			for(DWORD j=0; j<pBID->NumberOfModuleForwarderRefs; j++)
			{
				PIMAGE_BOUND_FORWARDER_REF pBFR = (PIMAGE_BOUND_FORWARDER_REF)pIter;
				pIter += sizeof(IMAGE_BOUND_FORWARDER_REF);
				dwOffset += sizeof(IMAGE_BOUND_FORWARDER_REF);

				// 
				szItem.Format("[%08X : %02d] IMAGE_BOUND_FORWARDER_REF", dwOffset, j);
				HTREEITEM hFoward = Tv()->InsertItem(szItem, hField);

				// TimeDateStamp
				SYSTEMTIME st;
				FILETIME ft;
				ULARGE_INTEGER li;
				memset(&st, 0x00, sizeof(st));
				st.wYear = 1970, st.wMonth = 1, st.wDay = 1, st.wHour = 9;
				SystemTimeToFileTime(&st, &ft);
				li.HighPart = ft.dwHighDateTime;
				li.LowPart  = ft.dwLowDateTime;
				li.QuadPart += ((unsigned __int64)pBFR->TimeDateStamp * 10000000L);
				ft.dwHighDateTime = li.HighPart;
				ft.dwLowDateTime = li.LowPart;
				FileTimeToSystemTime(&ft, &st);
				szItem.Format("TimeDateStamp               0x%08X, "
					"%04d/%02d/%02d-%02d:%02d:%02d", pBID->TimeDateStamp, 
					st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
				HTREEITEM hField2 = Tv()->InsertItem(szItem, hFoward);

				// OffsetModuleName
				szItem.Format("OffsetModuleName            0x%04X", pBFR->OffsetModuleName);
				hField2 = Tv()->InsertItem(szItem, hFoward);
				DWORD dwRawOffset = m_dwBndImg + pBFR->OffsetModuleName;
				LPSTR pszDllName = (LPSTR)(m_pImgView + dwRawOffset);
				szItem.Format("[%08X] %s", dwRawOffset, pszDllName);
				hChild = Tv()->InsertItem(szItem, hField2);

				// Reserved
				szItem.Format("Reserved                    0x%04X", pBFR->Reserved);
				hField2 = Tv()->InsertItem(szItem, hBound);
			}
		}
		nBndCnt++;
	}
}

void CImpAnalyzerDlg::ParseIATBlock(PIMAGE_DATA_DIRECTORY pddIat, HTREEITEM hRoot)
{
	CString	szItem;
	DWORD	dwOffset = pddIat->VirtualAddress - m_nDtImp;
	LPDWORD pdwIAT = (LPDWORD)(m_pImgView + dwOffset);
	DWORD	dwIatSize = 0;

	szItem.Format("[%08X] IAT", dwOffset);
	HTREEITEM hIatTbl = Tv()->InsertItem(szItem, hRoot);

	for(int i=0; dwIatSize < pddIat->Size; i++, dwIatSize += sizeof(DWORD))
	{
		if(pdwIAT[i])
			szItem.Format("[%08X : %03d] 0x%08X", dwOffset + dwIatSize, i, pdwIAT[i]);
		else
			szItem.Format("[%08X : %03d] 0", dwOffset + dwIatSize, i);
		Tv()->InsertItem(szItem, hIatTbl);
	}
}
