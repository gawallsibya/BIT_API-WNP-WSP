// ImpAnalyzerDlg.h : ��� ����
//

#pragma once


// CImpAnalyzerDlg ��ȭ ����
class CImpAnalyzerDlg : public CDialog
{
// ����
public:
	CImpAnalyzerDlg(CWnd* pParent = NULL);	// ǥ�� ������

// ��ȭ ���� ������
	enum { IDD = IDD_IMPANALYZER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����

	CString m_szPeName;
	HANDLE	m_hImgFile;
	HANDLE	m_hImgMap;
	LPBYTE	m_pImgView;

	DWORD	m_dwImpImg;
	INT		m_nDtImp;
	DWORD	m_dwBndImg;
	INT		m_nDtBnd;

	INT			m_nDW;
	INT			m_nDH;
	CFont		m_tvFont;

	CTreeCtrl* Tv() { return (CTreeCtrl*)GetDlgItem(IDC_TV_IMPINFO); }
	void CleanUp();

	void ParseImportSection(HTREEITEM);
	void ParseBoundSection(HTREEITEM);
	void ParseIATBlock(PIMAGE_DATA_DIRECTORY, HTREEITEM);

// ����
protected:
	HICON m_hIcon;

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnNMDblclkTvImpinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnGetdispinfoTvImpinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnDeleteitemTvImpinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnImage();
};
