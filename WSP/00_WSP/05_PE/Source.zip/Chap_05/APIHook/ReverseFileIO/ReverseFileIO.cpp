#include <Windows.h>
#define REVERSE_FILEIO_API extern "C" __declspec(dllexport)
#include "ReverseFileIO.h"

#define	FSZ_MODULE	"KERNEL32.DLL"
#define	FSZ_READ	"ReadFile"
#define	FSZ_WRITE	"WriteFile"


FARPROC  m_pfnOrigRead  = NULL;		// Original function address in callee
FARPROC  m_pfnHookRead  = NULL;		// Hook function address
FARPROC  m_pfnOrigWrite = NULL;		// Original function address in callee
FARPROC  m_pfnHookWrite = NULL;		// Hook function address


// Prototypes for the hooked functions
typedef BOOL (WINAPI *PFN_FILEIO)(HANDLE, LPVOID, DWORD, LPDWORD, LPOVERLAPPED);
BOOL WINAPI ReverseReadFile (HANDLE, LPVOID,  DWORD, LPDWORD, LPOVERLAPPED);
BOOL WINAPI ReverseWriteFile(HANDLE, LPCVOID, DWORD, LPDWORD, LPOVERLAPPED);
bool ReplaceIATEntry(LPCSTR, FARPROC, FARPROC, HMODULE);

BOOL APIENTRY DllMain(HANDLE hModule, DWORD  dwReason, LPVOID)
{
	if(dwReason == DLL_PROCESS_ATTACH)
	{
		HMODULE hReplaseDll = GetModuleHandleA(FSZ_MODULE);
		if(!hReplaseDll)
			return TRUE;

		////////////////////////////////////////////////////////////////////////
		// ReadFile Hooking...
		m_pfnHookRead = (FARPROC)ReverseReadFile;
		m_pfnOrigRead = GetProcAddress(hReplaseDll, FSZ_READ);
		if(!m_pfnOrigRead)
			return TRUE;

		if(!ReplaceIATEntry(FSZ_MODULE, m_pfnOrigRead, 
							m_pfnHookRead, GetModuleHandleA(NULL)))
			return TRUE;
		////////////////////////////////////////////////////////////////////////

		////////////////////////////////////////////////////////////////////////
		// WriteFile Hooking...
		m_pfnHookWrite = (FARPROC)ReverseWriteFile;
		m_pfnOrigWrite = GetProcAddress(hReplaseDll, FSZ_WRITE);
		if(!m_pfnOrigWrite)
		{
			ReplaceIATEntry(FSZ_MODULE, 
				m_pfnHookRead, m_pfnOrigRead, GetModuleHandleA(NULL));
			return TRUE;
		}

		if(!ReplaceIATEntry(FSZ_MODULE, m_pfnOrigWrite, 
							m_pfnHookWrite, GetModuleHandleA(NULL)))
		{
			ReplaceIATEntry(FSZ_MODULE, 
				m_pfnHookRead, m_pfnOrigRead, GetModuleHandleA(NULL));
			return TRUE;
		}
		////////////////////////////////////////////////////////////////////////
	}
	else
	if(dwReason == DLL_PROCESS_DETACH)
	{
			ReplaceIATEntry(FSZ_MODULE, 
				m_pfnHookRead, m_pfnOrigRead, GetModuleHandleA(NULL));
			ReplaceIATEntry(FSZ_MODULE, 
				m_pfnHookWrite, m_pfnOrigWrite, GetModuleHandleA(NULL));
	}

	return TRUE;
}

BOOL WINAPI ReverseReadFile(HANDLE hFile, 
							LPVOID lpBuffer, 
							DWORD nNumberOfBytesToRead, 
							LPDWORD lpNumberOfBytesRead, 
							LPOVERLAPPED lpOverlapped)
{
	BOOL bIsOK =  ReadFile(hFile, 
						   lpBuffer, 
						   nNumberOfBytesToRead, 
						   lpNumberOfBytesRead, 
						   lpOverlapped);
	if(!bIsOK)
		return FALSE;

	LPBYTE lpSrc = (LPBYTE)lpBuffer;
	DWORD  dwNumRev = ((*lpNumberOfBytesRead) >> 1);
	for(DWORD i=0; i<dwNumRev; i++)
	{
		BYTE ch = lpSrc[i];
		lpSrc[i] = lpSrc[(*lpNumberOfBytesRead) - i - 1];
		lpSrc[*lpNumberOfBytesRead - i - 1] = ch;
	}

	return TRUE;
}

BOOL WINAPI ReverseWriteFile(HANDLE hFile, 
							 LPCVOID lpBuffer, 
							 DWORD nNumberOfBytesToWrite, 
							 LPDWORD lpNumberOfBytesWritten, 
							 LPOVERLAPPED lpOverlapped)
{
	LPBYTE lpSrc = (LPBYTE)lpBuffer;
	if(*((LPWORD)lpSrc) != IMAGE_DOS_SIGNATURE)
	{
		DWORD  dwNumRev = (nNumberOfBytesToWrite>>1);
		for(DWORD i=0; i<dwNumRev; i++)
		{
			BYTE ch = lpSrc[i];
			lpSrc[i] = lpSrc[nNumberOfBytesToWrite - i - 1];
			lpSrc[nNumberOfBytesToWrite - i - 1] = ch;
		}
	}

	return WriteFile(hFile, 
					 lpBuffer, 
					 nNumberOfBytesToWrite, 
					 lpNumberOfBytesWritten, 
					 lpOverlapped);
}
///////////////////////////////////////////////////////////////////////////////


bool ReplaceIATEntry(LPCSTR pszRepDllName, FARPROC pfnCurFunc, 
					 FARPROC pfnNewFunc, HINSTANCE hModInst) 
{
	LPBYTE  pImageBase = (LPBYTE)hModInst;
	if(!pImageBase)
		return false;

	PIMAGE_DOS_HEADER pIDH = (PIMAGE_DOS_HEADER)pImageBase;
	if(pIDH->e_magic != IMAGE_DOS_SIGNATURE)
		return false;

	PIMAGE_NT_HEADERS pINH = (PIMAGE_NT_HEADERS)(pImageBase + pIDH->e_lfanew);
	if(pINH->Signature != IMAGE_NT_SIGNATURE)
		return false;

	PIMAGE_DATA_DIRECTORY pIDD = &pINH->
		OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
	PIMAGE_IMPORT_DESCRIPTOR pIID = 
		(PIMAGE_IMPORT_DESCRIPTOR)(pImageBase + pIDD->VirtualAddress);

	for(; pIID->OriginalFirstThunk; pIID++)
	{
		LPSTR pszModName = (LPSTR)(pImageBase + pIID->Name);
		if(!strcmpi(pszModName, pszRepDllName)) 
			break;
	}
	if(!pIID->Name)
		return false;

	PIMAGE_THUNK_DATA pThunk = (PIMAGE_THUNK_DATA)(pImageBase + pIID->FirstThunk);
	for(; pThunk->u1.Function; pThunk++) 
	{
		FARPROC* ppfn = (FARPROC*)&pThunk->u1.Function;
		if(*ppfn == pfnCurFunc)
		{
			*ppfn = pfnNewFunc;
			return true;
		}
	}

	return false;
}
