#ifndef __DLLBASIC_H__
#define __DLLBASIC_H__

#ifndef DLLBASIC_API
#define DLLBASIC_API extern "C" __declspec(dllimport)
#endif

DLLBASIC_API void WINAPI DrawTextPos04(HDC hDC, LPTSTR pszText, POINT ptPos);
DLLBASIC_API SIZE WINAPI CalcTextWidth06(HDC hDC, LPTSTR pszText);
DLLBASIC_API BOOL WINAPI IsPointInRect11(RECT rcRgn, POINT ptPos);

#endif	//__DLLBASIC_H__