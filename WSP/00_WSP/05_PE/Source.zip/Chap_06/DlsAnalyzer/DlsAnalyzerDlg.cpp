// DlsAnalyzerDlg.cpp : ���� ����
//

#include "stdafx.h"
#include "DlsAnalyzer.h"
#include "DlsAnalyzerDlg.h"

#include <DelayImp.h>
#include ".\dlsanalyzerdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ���� ���α׷� ������ ���Ǵ� CAboutDlg ��ȭ �����Դϴ�.

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// ��ȭ ���� ������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ����

// ����
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CDlsAnalyzerDlg ��ȭ ����



CDlsAnalyzerDlg::CDlsAnalyzerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDlsAnalyzerDlg::IDD, pParent)
	, m_szPeName(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_hImgFile	= INVALID_HANDLE_VALUE;
	m_hImgMap	= NULL;
	m_pImgView	= NULL;

	m_dwDlsImg	= 0;
	m_nDelta	= 0;
}

void CDlsAnalyzerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDT_IMAGE, m_szPeName);
}

BEGIN_MESSAGE_MAP(CDlsAnalyzerDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_NOTIFY(NM_DBLCLK, IDC_TV_DLSINFO, OnNMDblclkTvDlsinfo)
	ON_NOTIFY(TVN_GETDISPINFO, IDC_TV_DLSINFO, OnTvnGetdispinfoTvDlsinfo)
	ON_NOTIFY(TVN_DELETEITEM, IDC_TV_DLSINFO, OnTvnDeleteitemTvDlsinfo)
	ON_BN_CLICKED(IDC_BTN_IMAGE, OnBnClickedBtnImage)
END_MESSAGE_MAP()


// CDlsAnalyzerDlg �޽��� ó����

BOOL CDlsAnalyzerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// �ý��� �޴��� "����..." �޴� �׸��� �߰��մϴ�.

	// IDM_ABOUTBOX�� �ý��� ���� ������ �־�� �մϴ�.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	// �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	m_tvFont.CreatePointFont(90, "����ü");
	Tv()->SetFont(&m_tvFont);

	CRect rcp;
	GetWindowRect(rcp);
	CRect rcc;
	GetClientRect(rcc);

	CRect rct;
	Tv()->GetWindowRect(rct);
	m_nDW = (rct.left - rcp.left + 1) - ((rcp.Width() - rcc.Width())>>1);
	m_nDH = (rct.top - rcp.top + 1) - (rcp.Height() - rcc.Height());
	
	return TRUE;  // ��Ʈ�ѿ� ���� ��Ŀ���� �������� ���� ��� TRUE�� ��ȯ�մϴ�.
}

void CDlsAnalyzerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// ��ȭ ���ڿ� �ּ�ȭ ���߸� �߰��� ��� �������� �׸����� 
// �Ʒ� �ڵ尡 �ʿ��մϴ�. ����/�� ���� ����ϴ� MFC ���� ���α׷��� ��쿡��
// �����ӿ�ũ���� �� �۾��� �ڵ����� �����մϴ�.

void CDlsAnalyzerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// ����ڰ� �ּ�ȭ�� â�� ���� ���ȿ� Ŀ���� ǥ�õǵ��� �ý��ۿ���
//  �� �Լ��� ȣ���մϴ�. 
HCURSOR CDlsAnalyzerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CDlsAnalyzerDlg::OnDestroy()
{
	CDialog::OnDestroy();

	CleanUp();
}

void CDlsAnalyzerDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	if(Tv()->GetSafeHwnd())
	{
		cx -= ( m_nDW * 2 );
		cy -= ( m_nDH + m_nDW);
		Tv()->SetWindowPos(NULL, 0, 0, cx, cy, SWP_NOMOVE|SWP_NOZORDER);
	}
}

void CDlsAnalyzerDlg::OnNMDblclkTvDlsinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CDlsAnalyzerDlg::OnTvnGetdispinfoTvDlsinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTVDISPINFO pTVDispInfo = reinterpret_cast<LPNMTVDISPINFO>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CDlsAnalyzerDlg::OnTvnDeleteitemTvDlsinfo(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	*pResult = 0;
}

void CDlsAnalyzerDlg::OnBnClickedBtnImage()
{
	TCHAR szDefExt[] = "exe";
	TCHAR szFilter[] = "���� ���ø����̼�(*.exe)|*.exe|"
		"���� ���̺귯��(*.dll)|*.dll|��� ����(*.*)|*.*||";

	CFileDialog dlg(TRUE, szDefExt, "", 
		OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT, szFilter);
	if(dlg.DoModal() != IDOK)
		return;

	CleanUp();

	m_szPeName = dlg.GetPathName();
	try
	{

		m_hImgFile = CreateFile(m_szPeName, GENERIC_READ, FILE_SHARE_READ,
								NULL, OPEN_EXISTING, 0,NULL);
		if(m_hImgFile == INVALID_HANDLE_VALUE)
			throw MAKE_HRESULT(1, FACILITY_WIN32, GetLastError());

		m_hImgMap = CreateFileMapping(m_hImgFile, NULL, 
									  PAGE_READONLY, 0, 0, NULL);
		if(!m_hImgMap)
			throw MAKE_HRESULT(1, FACILITY_WIN32, GetLastError());

		m_pImgView = (LPBYTE)MapViewOfFile(m_hImgMap, FILE_MAP_READ, 0, 0, 0);
		if(!m_pImgView)
			throw MAKE_HRESULT(1, FACILITY_WIN32, GetLastError());


		PIMAGE_DOS_HEADER pIDH = (PIMAGE_DOS_HEADER)m_pImgView;
		if(pIDH->e_magic != IMAGE_DOS_SIGNATURE)
			throw "PE ������ ���� ������ �ƴմϴ�";

		PIMAGE_NT_HEADERS pINH = (PIMAGE_NT_HEADERS)(m_pImgView + pIDH->e_lfanew);
		if(pINH->Signature != IMAGE_NT_SIGNATURE)
			throw "PE ������ ���� ������ �ƴմϴ�";

		PIMAGE_DATA_DIRECTORY pIDD = 
			&pINH->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_DELAY_IMPORT];
		if(!pIDD->Size && !pIDD->VirtualAddress)
			throw "���� ����Ʈ ������ �������� �ʽ��ϴ�.";

		LPBYTE pIterSec = m_pImgView + pIDH->e_lfanew + sizeof(IMAGE_NT_HEADERS);
		PIMAGE_SECTION_HEADER pISH = NULL;
		for(INT i=0; i<pINH->FileHeader.NumberOfSections; i++)
		{
			PIMAGE_SECTION_HEADER pTemp = (PIMAGE_SECTION_HEADER)pIterSec;
			pIterSec += sizeof(IMAGE_SECTION_HEADER);

			if(!memcmp(pTemp->Name, ".didat\x0\x0", IMAGE_SIZEOF_SHORT_NAME))
			{
				pISH = pTemp;
				break;
			}
		}
		if(!pISH)
			throw "���� ����Ʈ ������ �������� �ʽ��ϴ�.";

		m_dwDlsImg = pISH->PointerToRawData;
		m_nDelta = pISH->VirtualAddress - m_dwDlsImg;

		CString szItem;
		szItem.Format("���� �ε� ����Ʈ ����");
		HTREEITEM hRoot = Tv()->InsertItem(szItem, NULL);

		DWORD dwOffset = m_dwDlsImg;
		LPBYTE pIter = m_pImgView + dwOffset;
		INT nImpCnt = 0;
		for(;;)
		{
			PImgDelayDescr pDelay = (PImgDelayDescr)pIter;
			pIter += sizeof(ImgDelayDescr);
			if(!pDelay->grAttrs && !pDelay->rvaDLLName)
				break;

			// 
			szItem.Format("[%08X : %02d] ImgDelayDescr", dwOffset, nImpCnt);
			HTREEITEM hDelay = Tv()->InsertItem(szItem, hRoot);
			dwOffset += sizeof(PImgDelayDescr);

			// grAttrs
			szItem.Format("grAttrs      0x%08X", pDelay->grAttrs);
			HTREEITEM hField = Tv()->InsertItem(szItem, hDelay);

			// rvaDLLName
			szItem.Format("rvaDLLName   0x%08X", pDelay->rvaDLLName);
			hField = Tv()->InsertItem(szItem, hDelay);
			PIMAGE_SECTION_HEADER pSec = FindSection(pDelay->rvaDLLName);
			CHAR szSecName[9];
			strncpy(szSecName, (LPSTR)pSec->Name, sizeof(pSec->Name));
			szSecName[sizeof(pSec->Name)] = 0x00;
			DWORD dwRawOffset = pDelay->rvaDLLName - 
				(pSec->VirtualAddress - pSec->PointerToRawData);
			LPSTR pszDllName = (LPSTR)(m_pImgView + dwRawOffset);
			szItem.Format("[%08X] %s (in %s)", dwRawOffset, pszDllName, szSecName);
			Tv()->InsertItem(szItem, hField);

			// rvaHmod
			szItem.Format("rvaHmod      0x%08X", pDelay->rvaHmod);
			hField = Tv()->InsertItem(szItem, hDelay);
			pSec = FindSection(pDelay->rvaHmod);
			strncpy(szSecName, (LPSTR)pSec->Name, sizeof(pSec->Name));
			szSecName[sizeof(pSec->Name)] = 0x00;
			dwRawOffset = pDelay->rvaHmod - 
				(pSec->VirtualAddress - pSec->PointerToRawData);
			HINSTANCE hInst = (HINSTANCE)(*(m_pImgView + dwRawOffset));
			szItem.Format("[%08X] %08X (in %s)", dwRawOffset, hInst, szSecName);
			Tv()->InsertItem(szItem, hField);

			// rvaIAT
			szItem.Format("rvaIAT       0x%08X", pDelay->rvaIAT);
			hField = Tv()->InsertItem(szItem, hDelay);
			szItem.Format("[%08X] IAT(����Ʈ �ּ� ���̺�)");
			HTREEITEM hIat = Tv()->InsertItem(szItem, hField);
			dwRawOffset = pDelay->rvaIAT - m_nDelta;
			LPDWORD pdwIAT = (LPDWORD)(m_pImgView + dwRawOffset);
			for(i=0; pdwIAT[i]; i++)
			{
				szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwIAT[i]);
				HTREEITEM hChild = Tv()->InsertItem(szItem, hIat);
				dwRawOffset += sizeof(DWORD);
			}

			// rvaINT
			szItem.Format("rvaINT       0x%08X", pDelay->rvaINT);
			hField = Tv()->InsertItem(szItem, hDelay);
			szItem.Format("[%08X] INT(����Ʈ �̸� ���̺�)");
			HTREEITEM hInt = Tv()->InsertItem(szItem, hField);
			dwRawOffset = pDelay->rvaINT - m_nDelta;
			LPDWORD pdwINT = (LPDWORD)(m_pImgView + dwRawOffset);
			for(int i=0; pdwINT[i]; i++)
			{
				szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwINT[i]);
				HTREEITEM hChild = Tv()->InsertItem(szItem, hInt);
				dwRawOffset += sizeof(DWORD);

				if(pdwINT[i] & 0x80000000)
				{
					WORD wOrdinal = (WORD)(pdwINT[i] & 0x0000FFFF);
					szItem.Format("[%08X] ���� %d", dwRawOffset, wOrdinal);
				}
				else
				{
					DWORD dwRawOffset2 = pdwINT[i] - m_nDelta;
					PIMAGE_IMPORT_BY_NAME pIBN = (PIMAGE_IMPORT_BY_NAME)(m_pImgView + dwRawOffset2);
					szItem.Format("[%08X] Hint 0x%04d", dwRawOffset2, pIBN->Hint);
					dwRawOffset2 += sizeof(pIBN->Hint);
					Tv()->InsertItem(szItem, hChild);
					LPSTR pszFuncName = (LPSTR)&pIBN->Name;
					szItem.Format("[%08X] Name %s", dwRawOffset2, pszFuncName);
				}
				Tv()->InsertItem(szItem, hChild);
			}

			// rvaBoundIAT
			szItem.Format("rvaBoundIAT  0x%08X", pDelay->rvaBoundIAT);
			hField = Tv()->InsertItem(szItem, hDelay);
			szItem.Format("[%08X] Bound IAT(�ٿ�� ����Ʈ �ּ� ���̺�)");
			HTREEITEM hBIat = Tv()->InsertItem(szItem, hField);
			dwRawOffset = pDelay->rvaBoundIAT - m_nDelta;
			LPDWORD pdwBIAT = (LPDWORD)(m_pImgView + dwRawOffset);
			for(i=0; pdwBIAT[i]; i++)
			{
				szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwBIAT[i]);
				HTREEITEM hChild = Tv()->InsertItem(szItem, hBIat);
				dwRawOffset += sizeof(DWORD);
			}

			// rvaUnloadIAT
			szItem.Format("rvaUnloadIAT 0x%08X", pDelay->rvaUnloadIAT);
			hField = Tv()->InsertItem(szItem, hDelay);
			szItem.Format("[%08X] Unload IAT(��ε� ����Ʈ �ּ� ���̺�)");
			HTREEITEM hUIat = Tv()->InsertItem(szItem, hField);
			dwRawOffset = pDelay->rvaUnloadIAT - m_nDelta;
			LPDWORD pdwUIAT = (LPDWORD)(m_pImgView + dwRawOffset);
			for(i=0; pdwUIAT[i]; i++)
			{
				szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwUIAT[i]);
				HTREEITEM hChild = Tv()->InsertItem(szItem, hUIat);
				dwRawOffset += sizeof(DWORD);
			}

			// dwTimeStamp
			szItem.Format("dwTimeStamp  0x%08X", pDelay->dwTimeStamp);
			hField = Tv()->InsertItem(szItem, hDelay);

			nImpCnt++;
		}
	}
	catch(HRESULT hr)
	{
		CleanUp();
		CDlsAnalyzerApp::ShowErrorMessage(hr);
	}
	catch(LPCSTR pszMsg)
	{
		m_dwDlsImg = 0;

		CleanUp();
		AfxMessageBox(pszMsg);
	}

	UpdateData(FALSE);
}

void CDlsAnalyzerDlg::CleanUp()
{
	Tv()->DeleteAllItems();

	m_dwDlsImg	= 0;

	if(m_pImgView)
	{
		UnmapViewOfFile(m_pImgView);
		m_pImgView = NULL;
	}
	if(m_hImgMap)
	{
		CloseHandle(m_hImgMap);
		m_hImgMap	= NULL;
	}
	if(m_hImgFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hImgFile);
		m_hImgFile	= INVALID_HANDLE_VALUE;
	}

	m_szPeName.Empty();
}

PIMAGE_SECTION_HEADER CDlsAnalyzerDlg::FindSection(DWORD dwVirAddr)
{
	PIMAGE_DOS_HEADER pIDH = (PIMAGE_DOS_HEADER)m_pImgView;
	PIMAGE_NT_HEADERS pINH = (PIMAGE_NT_HEADERS)(m_pImgView + pIDH->e_lfanew);
	LPBYTE pIterSec = m_pImgView + pIDH->e_lfanew + sizeof(IMAGE_NT_HEADERS);

	for(INT i=0; i<pINH->FileHeader.NumberOfSections; i++)
	{
		PIMAGE_SECTION_HEADER pISH = (PIMAGE_SECTION_HEADER)pIterSec;
		pIterSec += sizeof(IMAGE_SECTION_HEADER);
		if(	(dwVirAddr >= pISH->VirtualAddress) &&
			(dwVirAddr <  pISH->VirtualAddress + pISH->Misc.VirtualSize))
			return pISH;
	}

	return NULL;
}

void CDlsAnalyzerDlg::ParseDelayImportSection(HTREEITEM hRoot)
{
	CString	szItem;
	DWORD	dwOffset = m_dwDlsImg;
	LPBYTE	pIter	 = m_pImgView + dwOffset;
	INT		nImpCnt  = 0;

	for(;;)
	{
		PImgDelayDescr pDelay = (PImgDelayDescr)pIter;
		pIter += sizeof(ImgDelayDescr);
		if(!pDelay->grAttrs && !pDelay->rvaDLLName)
			break;

		// 
		szItem.Format("[%08X : %02d] ImgDelayDescr", dwOffset, nImpCnt);
		HTREEITEM hDelay = Tv()->InsertItem(szItem, hRoot);
		dwOffset += sizeof(PImgDelayDescr);

		// grAttrs
		szItem.Format("grAttrs      0x%08X", pDelay->grAttrs);
		HTREEITEM hField = Tv()->InsertItem(szItem, hDelay);

		// rvaDLLName
		szItem.Format("rvaDLLName   0x%08X", pDelay->rvaDLLName);
		hField = Tv()->InsertItem(szItem, hDelay);
		PIMAGE_SECTION_HEADER pSec = FindSection(pDelay->rvaDLLName);
		CHAR szSecName[9];
		strncpy(szSecName, (LPSTR)pSec->Name, sizeof(pSec->Name));
		szSecName[sizeof(pSec->Name)] = 0x00;
		DWORD dwRawOffset = pDelay->rvaDLLName - 
			(pSec->VirtualAddress - pSec->PointerToRawData);
		LPSTR pszDllName = (LPSTR)(m_pImgView + dwRawOffset);
		szItem.Format("[%08X] %s (in %s)", dwRawOffset, pszDllName, szSecName);
		Tv()->InsertItem(szItem, hField);

		// rvaHmod
		szItem.Format("rvaHmod      0x%08X", pDelay->rvaHmod);
		hField = Tv()->InsertItem(szItem, hDelay);
		pSec = FindSection(pDelay->rvaHmod);
		strncpy(szSecName, (LPSTR)pSec->Name, sizeof(pSec->Name));
		szSecName[sizeof(pSec->Name)] = 0x00;
		dwRawOffset = pDelay->rvaHmod - 
			(pSec->VirtualAddress - pSec->PointerToRawData);
		HINSTANCE hInst = (HINSTANCE)(*(m_pImgView + dwRawOffset));
		szItem.Format("[%08X] %08X (in %s)", dwRawOffset, hInst, szSecName);
		Tv()->InsertItem(szItem, hField);

		// rvaIAT
		szItem.Format("rvaIAT       0x%08X", pDelay->rvaIAT);
		hField = Tv()->InsertItem(szItem, hDelay);
		szItem.Format("[%08X] IAT(����Ʈ �ּ� ���̺�)");
		HTREEITEM hIat = Tv()->InsertItem(szItem, hField);
		dwRawOffset = pDelay->rvaIAT - m_nDelta;
		LPDWORD pdwIAT = (LPDWORD)(m_pImgView + dwRawOffset);
		for(INT i=0; pdwIAT[i]; i++)
		{
			szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwIAT[i]);
			HTREEITEM hChild = Tv()->InsertItem(szItem, hIat);
			dwRawOffset += sizeof(DWORD);
		}

		// rvaINT
		szItem.Format("rvaINT       0x%08X", pDelay->rvaINT);
		hField = Tv()->InsertItem(szItem, hDelay);
		szItem.Format("[%08X] INT(����Ʈ �̸� ���̺�)");
		HTREEITEM hInt = Tv()->InsertItem(szItem, hField);
		dwRawOffset = pDelay->rvaINT - m_nDelta;
		LPDWORD pdwINT = (LPDWORD)(m_pImgView + dwRawOffset);
		for(i=0; pdwINT[i]; i++)
		{
			szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwINT[i]);
			HTREEITEM hChild = Tv()->InsertItem(szItem, hInt);
			dwRawOffset += sizeof(DWORD);

			if(pdwINT[i] & 0x80000000)
			{
				WORD wOrdinal = (WORD)(pdwINT[i] & 0x0000FFFF);
				szItem.Format("[%08X] ���� %d", dwRawOffset, wOrdinal);
			}
			else
			{
				DWORD dwRawOffset2 = pdwINT[i] - m_nDelta;
				PIMAGE_IMPORT_BY_NAME pIBN = (PIMAGE_IMPORT_BY_NAME)(m_pImgView + dwRawOffset2);
				szItem.Format("[%08X] Hint 0x%04d", dwRawOffset2, pIBN->Hint);
				dwRawOffset2 += sizeof(pIBN->Hint);
				Tv()->InsertItem(szItem, hChild);
				LPSTR pszFuncName = (LPSTR)&pIBN->Name;
				szItem.Format("[%08X] Name %s", dwRawOffset2, pszFuncName);
			}
			Tv()->InsertItem(szItem, hChild);
		}

		// rvaBoundIAT
		szItem.Format("rvaBoundIAT  0x%08X", pDelay->rvaBoundIAT);
		hField = Tv()->InsertItem(szItem, hDelay);
		szItem.Format("[%08X] Bound IAT(�ٿ�� ����Ʈ �ּ� ���̺�)");
		HTREEITEM hBIat = Tv()->InsertItem(szItem, hField);
		dwRawOffset = pDelay->rvaBoundIAT - m_nDelta;
		LPDWORD pdwBIAT = (LPDWORD)(m_pImgView + dwRawOffset);
		for(i=0; pdwBIAT[i]; i++)
		{
			szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwBIAT[i]);
			HTREEITEM hChild = Tv()->InsertItem(szItem, hBIat);
			dwRawOffset += sizeof(DWORD);
		}

		// rvaUnloadIAT
		szItem.Format("rvaUnloadIAT 0x%08X", pDelay->rvaUnloadIAT);
		hField = Tv()->InsertItem(szItem, hDelay);
		szItem.Format("[%08X] Unload IAT(��ε� ����Ʈ �ּ� ���̺�)");
		HTREEITEM hUIat = Tv()->InsertItem(szItem, hField);
		dwRawOffset = pDelay->rvaUnloadIAT - m_nDelta;
		LPDWORD pdwUIAT = (LPDWORD)(m_pImgView + dwRawOffset);
		for(i=0; pdwUIAT[i]; i++)
		{
			szItem.Format("[%08X : %03d] 0x%08X", dwRawOffset, i, pdwUIAT[i]);
			HTREEITEM hChild = Tv()->InsertItem(szItem, hUIat);
			dwRawOffset += sizeof(DWORD);
		}

		// dwTimeStamp
		szItem.Format("dwTimeStamp  0x%08X", pDelay->dwTimeStamp);
		hField = Tv()->InsertItem(szItem, hDelay);

		nImpCnt++;
	}
}
