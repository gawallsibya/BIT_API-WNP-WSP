#ifndef __DLLBASIC_H__
#define __DLLBASIC_H__

#ifdef __cplusplus
extern "C" {
#endif
void WINAPI DrawTextPos04(HDC hDC, LPTSTR pszText, POINT ptPos);
SIZE WINAPI CalcTextWidth06(HDC hDC, LPTSTR pszText);
BOOL WINAPI IsPointInRect11(RECT rcRgn, POINT ptPos);
#ifdef __cplusplus
}
#endif

#endif	//__DLLBASIC_H__