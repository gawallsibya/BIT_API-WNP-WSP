// ExpAnalyzerDlg.h : ��� ����
//

#pragma once


// CExpAnalyzerDlg ��ȭ ����
class CExpAnalyzerDlg : public CDialog
{
// ����
public:
	CExpAnalyzerDlg(CWnd* pParent = NULL);	// ǥ�� ������

// ��ȭ ���� ������
	enum { IDD = IDD_EXPANALYZER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ����

	CString m_szPeName;
	HANDLE	m_hImgFile;
	HANDLE	m_hImgMap;
	LPBYTE	m_pImgView;

	DWORD	m_dwExpImg;
	INT		m_nDelta;

	INT			m_nDW;
	INT			m_nDH;
	CFont		m_tvFont;

	CTreeCtrl* Tv() { return (CTreeCtrl*)GetDlgItem(IDC_TV_EXPINFO); }
	void CleanUp();

	void ParseExportSection(PIMAGE_DATA_DIRECTORY, DWORD);

// ����
protected:
	HICON m_hIcon;

	// �޽��� �� �Լ��� �����߽��ϴ�.
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTvnGetdispinfoTvExpinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMRclickTvExpinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnDeleteitemTvExpinfo(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedBtnImage();
};
