#ifndef __DLLENTRYPOINT_H__
#define __DLLENTRYPOINT_H__

#ifndef DLLENTRYPOINT_API
#define DLLENTRYPOINT_API extern "C" __declspec(dllimport)
#endif

DLLENTRYPOINT_API void WINAPI DrawTextPos04(HDC hDC, LPTSTR pszText, POINT ptPos);
DLLENTRYPOINT_API SIZE WINAPI CalcTextWidth06(HDC hDC, LPTSTR pszText);
DLLENTRYPOINT_API BOOL WINAPI IsPointInRect11(RECT rcRgn, POINT ptPos);

#endif	//__DLLENTRYPOINT_H__