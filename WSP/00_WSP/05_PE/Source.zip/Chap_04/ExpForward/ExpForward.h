#ifndef __EXPFORWARD_H__
#define __EXPFORWARD_H__

void WINAPI DrawTextPos04(HDC hDC, LPTSTR pszText, POINT ptPos);
SIZE WINAPI CalcTextWidth06(HDC hDC, LPTSTR pszText);
BOOL WINAPI IsPointInRect11(RECT rcRgn, POINT ptPos);
BOOL WINAPI ForwardTextOut(HDC hdc, int nXStart, int nYStart, LPCSTR lpString, int cbString);

#endif	//__EXPFORWARD_H__
